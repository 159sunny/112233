// import { NzTableModule } from 'ng-zorro-antd/table';
import { Component, OnInit, Input } from '@angular/core';
import { saveAs } from 'file-saver';
import {DownloadService} from 'src/app/service/download/download.service';
import { from } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';

import { Location } from '@angular/common';
import { PlatformLocation} from '@angular/common';
import { V_AutoSavePatchInfoApi} from '../../service/api/index';
import { V_AutoSaveLocalUserGroupApi } from '../../service/api/index';

import { V_AutoCompareComputerInfoApi } from '../../service/api/index';
import { AutoEOSversionApi} from '../../service/api/index';

import { V_specificAppApi, V_AutoAPPnamekeyApi, AutoAPPversionApi, V_ComputernameApi } from '../../service/api/index';

import { V_AutoWINversionApi, AutoWINversionApi} from '../../service/api/index';

import { V_AutoOfcversionApi} from '../../service/api/index';

import { V_TwoUltiomServertotalApi, V_UltiomServertotalApi, V_AutoCompareComputerInfo} from '../../service/api/index';

import { V_admintotalApi} from '../../service/api/index';

import { V_admintotaldaybeforeApi} from '../../service/api/index';
import { SiteeosComponent } from 'src/app/modulesCode/indexmodules/siteeos/siteeos.component';



@Component({
  selector: 'app-tab-index',
  templateUrl: './tab-index.component.html',
  styleUrls: ['./tab-index.component.scss']
})
export class TabIndexComponent implements OnInit {
  @Input() offsion: any;
   public listdata;
   public dataSet;
   public showdata;
   eosversion: any;
   winname:any;
   public myVar;
   public clickNow;
   public dataindex;
   public viso;
   public site1;
   public sites;
   public UIsite;
  //  public sitecheck;
  //  判斷當前是哪個模塊的點擊事件
   site = this.platformLocation.hash.split("site=")[1];
  //  sitecheck = this.platformLocation.hash.split("site=")[1].split("&")[0];
   myVarTbody = this.platformLocation.hash.split("check=")[1].split("&")[0];
   month = this.platformLocation.hash.split("site=")[1].split("month=")[1];
   test = window.location.href;
   testzh=this.test.replace(/\%20/g,' ');
   sitecheck =this.testzh.split("site=")[1].split("&")[0];

  constructor(

    private downloadService: DownloadService,
    private activedRouter: ActivatedRoute,
    private platformLocation: PlatformLocation,
    private pacth: V_AutoSavePatchInfoApi,
    private local: V_AutoSaveLocalUserGroupApi,

    private eos: V_AutoCompareComputerInfoApi,
    private EOSversion: AutoEOSversionApi,

    private specificAppApi: V_specificAppApi,

    private winnamekey: V_AutoWINversionApi,
    private winversionlist: AutoWINversionApi,

    private TwoUltiomServertotal: V_TwoUltiomServertotalApi,
    private UltiomServertotal: V_UltiomServertotalApi,

    private todayadmintotal: V_admintotalApi,

    private berforadmintotal: V_admintotaldaybeforeApi,

    private ofcversion: V_AutoOfcversionApi,
    private computername: V_ComputernameApi,


  ) { }

  async ngOnInit() {
   this.myVar = this.platformLocation.hash.split("check=")[1].split("&")[0];
   this.clickNow = this.site.split("clickNow=")[1];
   this.UIsite=window.localStorage['sitename'];


   console.log("獲取的當前地址為2223"+ this.test);
   if (this.myVar != " ") {
     console.log("獲取到了點擊的那個");
     if (this.myVar == "2") {
      console.log("獲取到了點擊的那個2");
      this.chaxundatapath(this.site);
     } else if (this.myVar == "3") {
      this.chaxundatapassword(this.site);
     } else if (this.myVar == "5") {
      console.log("獲取到了點擊的那個5");
      this.eosversion = await this.queryEOSversion();
      console.log("獲取到了點擊的那個5"+this.eosversion);
       this.chaxun(this.site, this.eosversion);
     } else if (this.myVar == "9") {
      // console.log("獲取到了點擊的那個9");
      console.log("獲取到了點擊的那個:"+this.site);
      this.chaxunSpecifict(this.site);
     } else if (this.myVar =='4'){
       console.log("獲取到了點擊的那個4");
       console.log("當前是："+this.site);
       this.site=this.site.split("%20")[0]+" "+this.site.split("%20")[1];
       console.log("當前是w："+this.site);
       this.winname = await this.chaxunWin(this.site);
       this.chaxunWinVer(this.winname);
     } else if (this.myVar=='1') {
       this.site = this.platformLocation.hash.split("site=")[1].split("&")[0];
       console.log("ttttt:"+this.clickNow);
       if(this.clickNow=='0'){
        await this.chaxunSiteServeTwoUl(this.site);
       } else if (this.clickNow =='1') {
        console.log("ttttt:"+this.site);
        await this.chaxunSiteServeUl(this.site);
       }else{
        await this.chaxunSiteServeNowUl(this.site);
       }
     } else if (this.myVar=='6'){
       console.log("8888888888888");

       console.log(this.clickNow);
      //  this.dataindex = this.site.split(" ");
      await this.chaxunAcctal(this.clickNow);
     } else if (this.myVar=='7'){
      console.log("77777777777777777");
      console.log(this.clickNow);
      if(this.clickNow=='0'){
      await this.berfordata();
      }else if(this.clickNow=='1'){
        await this.todaydata();
       } else if(this.clickNow=='3'){
         await this.IncreAdmin();
       }
      //  this.clickNow=this.clickNow.toString();
      //  await this.berfordata();
     }  else if (this.myVar=='8') {
         console.log("當前點擊8888");
         this.OfficeScan();
     }
   }


   //獲取當前的url,并取得值
    // const urlt = this.platformLocation.hash;
    // // const yy = urlt.split("site=");
    // // const myVar = yy[1];
    // console.log("kkk當前地址"+this.myVar);
    // console.log("kkk當前地址2"+this.site);
    // // this.onRoute();

    // const afterUrl =  window.location.search.substring(1);
    // const afterUrl2 =  window.location.search.length>0?window.location.search.substring(1):" ";
    // console.log("當前的值為1："+afterUrl2);
    // const afterEqual = afterUrl.substring(afterUrl.indexOf('=')+1);

  }


    //下載excel檔
   public exportTable() {
    let FileName = 'Raw Data list 詳細數據';
    const table = <HTMLDivElement>document.getElementById('exportableTable');
    this.downloadService.exportTableAsExcelFile(table, FileName);
    // this.downloadService.exportAsExcelFile(this.showDataBack, FileName);
   }


   public async chaxundatapath(site: string) {
    const namelistw = [];
    let sitelist=[];
    console.log("Vvvvvvvv");
    console.log(site);
    if(site=='ALL'){
      // sitelist=this.sitename();
      let site = this.sitename();
      let sites = "'1'";
      site.forEach(date => {
      sites += ",'" + date + "'";
      });
    // console.log("Vvvvvvvv");
    // console.log(sites);
    // console.log("Vvvvvvvv");
      var queryacct = {
        "site": sites
        };
      const localinfo = await this.pacth.datalistpatchAll(queryacct).toPromise();
      console.log(localinfo['counts']);
       this.dataSet=localinfo['counts'];
       console.log(this.dataSet);

     (this.dataSet).forEach(async element => {
      namelistw.push(element);
      console.log(element);
    });
    this.showdata = namelistw;
     }else{
       site=site;
       const localinfo = await this.pacth.datalistpatch('"' + site + '"').toPromise();
    console.log(localinfo['counts']);
       this.dataSet=localinfo['counts'];
       console.log(this.dataSet);

    (this.dataSet).forEach(element => {
      namelistw.push(element);
      console.log(element);
    });
    this.showdata = namelistw;
     }
    // let sites=this.sitename();
    // const localinfo = await this.pacth.datalistpatch('"' + site + '"').toPromise();
    // console.log(localinfo['counts']);
    //    this.dataSet=localinfo['counts'];
    //    console.log(this.dataSet);

    // (this.dataSet).forEach(element => {
    //   namelistw.push(element);
    //   console.log(element);
    // });

    // this.showdata = namelistw;
    // return namelistw;
  }

  //點擊path模塊查詢
   public async chaxundatapath11(site: string) {
    const namelistw = [];
    const localinfo = await this.pacth.datalistpatch('"' + site + '"').toPromise();
    // console.log(localinfo['counts']);
       this.dataSet=localinfo;
    (this.dataSet['counts']).forEach(element => {
      namelistw.push(element);
      console.log(element);
    });

    this.showdata = namelistw;
    // return namelistw;
  }

  public async chaxundatapassword(site:string) {
    const namelistw = [];
    let sitlist=[];
    if(site=='ALL'){
      // sitlist = this.sitenameq();
      // console.log("wwwwwwwwwwwwwwwwww");
      // console.log(sitlist);
      // console.log("wwwwwwwwwwwwwwwwww");

      let site = this.sitename();
      let sites = "'1'";
      site.forEach(date => {
      sites += ",'" + date + "'";
  });
      var queryacct = {
        "site": sites
        };
      const localinfo = await this.local.datalistpasswordAll(queryacct).toPromise();
      this.dataSet = localinfo['counts'];
      console.log(this.dataSet);
      (this.dataSet).forEach(async element => {
      namelistw.push(element);
      console.log(element);
    });
    }else{
     site=site;
     const localinfo = await this.local.datalistpassword('"' + site + '"').toPromise();
     this.dataSet = localinfo['counts'];
     (this.dataSet).forEach(element => {
      namelistw.push(element);
      console.log(element);
    });
    }

    // console.log(localinfo['counts']);


    this.showdata = namelistw;
    // return namelistw;
  }


  public async queryEOSversion( ): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {


      const eosversion = await this.EOSversion.find().toPromise();
      // console.log("遍歷出來的eos版本" + eosversion);
      const version: string[] = [];
      eosversion.forEach(async data => {
         console.log(await Object.values(data).toString());
        // console.log("2222222"+this.Alloff);
        version.push(await Object.values(data).toString());

      });
      resolve(version);
  });
  }



  public async chaxun( site: string, Osversion: any[]) {
      console.log("777777777"+Osversion);
      // EOS total
      // let result = 0;
      // tslint:disable-next-line: prefer-for-of
      console.log(site);
      let sitlist=[];
      const sites=site;
      const namelistw = [];
      if(site=='All'){
        sitlist = this.sitenameq();
        for (let j = 0; j < Osversion.length; j++) {
          const version: string = '%' +  Osversion[j] + '%';
          // console.log(version, site);

          const actualresult = await this.eos.find(
            {where:
              {and: [
              {Sitename: {inq: sitlist}},
              {osversion: {like: version}}]
              }
              }
          ).toPromise();
          this.dataSet = actualresult;
          console.log("eos版本："+this.dataSet);
          (this.dataSet).forEach(async element => {
            console.log(await Object.values(element).toString());
            namelistw.push(element);
            console.log(element);
          });
        }
      }else{
        site=site;
        for (let j = 0; j < Osversion.length; j++) {
          const version: string = '%' +  Osversion[j] + '%';
          // console.log(version, site);

          const actualresult = await this.eos.find(
            {where:
              {and: [
              {Sitename: sites},
              {osversion: {like: version}}]
              }
              }
          ).toPromise();
          this.dataSet = actualresult;
          console.log("eos版本："+this.dataSet);
          (this.dataSet).forEach(async element => {
            console.log(await Object.values(element).toString());
            namelistw.push(element);
            console.log(element);
          });
        }
      }
      console.log("ggggggggggg");
      console.log(this.sites);
      // tslint:disable-next-line: prefer-for-of
      // for (let j = 0; j < Osversion.length; j++) {
      //   const version: string = '%' +  Osversion[j] + '%';
      //   // console.log(version, site);

      //   const actualresult = await this.eos.find(
      //     {where:
      //       {and: [
      //       {Sitename: {inq: sites}},
      //       {osversion: {like: version}}]
      //       }
      //       }
      //   ).toPromise();
      //   this.dataSet = actualresult;
      //   console.log("eos版本："+this.dataSet);
      //   (this.dataSet).forEach(async element => {
      //     console.log(await Object.values(element).toString());
      //     namelistw.push(element);
      //     console.log(element);
      //   });
      // }
      this.showdata = namelistw;


}

//特殊軟體
 public async chaxunSpecifict( app: string) {
  console.log("kkkkkkkkkkkkk");
  console.log("獲取當前的APP"+app);
  console.log("kkkkkkkkkkkkk");
  const namelistw = [];
  let site = this.sitename();
  console.log("kkkkkkkkkkkkk");
  site=this.sitename();

  let sites = "'1'";
  site.forEach(date => {
  sites += ",'" + date + "'";
      });
  var queryacct = {
    "tit":app,
    "site":sites,
    "tity":app
    };

    console.log("kkkkkkkkkkkkk");
    console.log(sites);
    console.log("kkkkkkkkkkkkk");
  const specificapp = await this.specificAppApi.specificappimg(queryacct).toPromise();
  this.dataSet = specificapp['counts'];
  console.log(specificapp);
  (this.dataSet).forEach(async element => {
    namelistw.push(element);
  });
  this.showdata = namelistw;
}

//window版本
 public async chaxunWin(Winnamekey: string) {
  return new Promise<any>(async (resolve, reject) => {
    const versionlist = await this.winversionlist.find(
      {where: { WINnameKey: Winnamekey}}
    ).toPromise();

    const version: string[] = [];
    versionlist.forEach(async data => {
    // console.log(await Object.values(data)[0].toString());

      version.push(await Object.values(data)[0].toString());

    });
    resolve(version);
});
}

/**
 * sitename  獲取當前的sitename
 */
public  sitename() {
  let name = [];
  if (window.localStorage['sitename'] === 'All') {
    name = window.localStorage['userpower'].split(',');
    console.log(name);
  } else {
    name.push(window.localStorage['sitename']);
  }
  return name;
}

public  sitenameq() {
  let name = [];
  if (window.localStorage['sitename'] === 'All') {
    name = window.localStorage['userpower'].split(',');
       let sitlist = "'1'";
       name.forEach(async date => {
          sitlist += ",'" + date + "'";
        });
    console.log(name);
  } else {
    name.push(window.localStorage['sitename']);
  }
  return name;
}

public async chaxunWinVer( Winname: string[]) {
  // console.log("獲取當前的APP"+app);
  let site = this.sitename();
  console.log('Winname');
  console.log(this.sitename());
  console.log('++++++++++++++++++++=+++');
  const namelistw = [];
  const Winver = await this.UltiomServertotal.find(
    { where: {and: [{osversion: {inq: Winname}}, {Sitename: {inq: site}}]} }
  ).toPromise();
  this.dataSet = Winver;
  console.log(Winver);
  (this.dataSet).forEach(async element => {
    namelistw.push(element);
  });
  this.showdata = namelistw;
}


public async chaxunSiteServeNowUl( clicksite: string) {
  // let site = this.sitename();
  console.log('Winname');
  // console.log(this.sitename());
  console.log('++++++++++++++++++++=+++');
  const namelistw = [];
  let sitlist=[];
  if(clicksite=='ALL'){
    sitlist = this.sitenameq();
    const Winver = await this.eos.find(
      { where:  {Sitename: {inq:sitlist}} }
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }else{
    clicksite=clicksite;
    const Winver = await this.eos.find(
      { where:  {Sitename: clicksite} }
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }

}


//獲取上一個月的serve詳細
public async chaxunSiteServeUl( clicksite: string) {
  // let site = this.sitename();
  console.log(clicksite);
  // console.log(this.sitename());
  console.log('++++++++++++++++++++=+++');
  console.log(clicksite);
  const namelistw = [];
  let sitlist=[];
  if(clicksite=='ALL'){
    sitlist = this.sitenameq();
    console.log("lllllllllllllll");
    console.log(sitlist);
    console.log("lllllllllllllll");
    const Winver = await this.UltiomServertotal.find(
      { where:  {Sitename: {inq: sitlist}} }
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }else{
    clicksite=clicksite;
    const Winver = await this.UltiomServertotal.find(
      { where:  {Sitename: clicksite} }
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }

}
//獲取前兩月的serve詳細
public async chaxunSiteServeTwoUl( clicksite: string) {
  // let site = this.sitename();
  console.log('Winname');
  // console.log(this.sitename());
  console.log('++++++++++++++++++++=+++');
  const namelistw = [];
  let sitlist=[];
  if(clicksite=='ALL'){
    clicksite=clicksite;
    sitlist = this.sitenameq();
    const Winver = await this.TwoUltiomServertotal.find(
      { where:  {Sitename: {inq: sitlist} }}
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }else{

    const Winver = await this.TwoUltiomServertotal.find(
      { where:  {Sitename: clicksite} }
    ).toPromise();
    this.dataSet = Winver;
    console.log(Winver);
    (this.dataSet).forEach(async element => {
      namelistw.push(element);
    });
    this.showdata = namelistw;
  }


}


public async chaxunAcctal( clicksite: string) {
  let site = this.sitename();
  let sites = "'1'";
  site.forEach(date => {
    sites += ",'" + date + "'";
  });
  if(clicksite=='0'){
    var queryacct = {
      "admintotaldp": 0,
      "admintotalUp": 3,
      "site": sites
      };
  } else if(clicksite=='1'){
    var queryacct = {
      "admintotaldp": 4,
      "admintotalUp": 7,
      "site": sites
      };
  } else if(clicksite=='2'){
    var queryacct = {
      "admintotaldp": 8,
      "admintotalUp": 0,
      "site": sites
      };
  }

  console.log('Winname');
  // console.log(this.sitename());
  console.log('++++++++++++++++++++=+++');
  const namelistw = [];
  const Winver = await this.todayadmintotal.counttotal(queryacct).toPromise();
  this.dataSet = Winver['counts'];
  console.log(Winver);
  (this.dataSet).forEach(async element => {
    namelistw.push(element);
  });
  this.showdata = namelistw;
}

//Monitor Administrators Group
public async berfordata(){

      // let total = 0;
      const namelistw = [];
      let site = this.sitename();
      console.log("yyyyyyy");
      console.log(site);
      console.log("yyyyyyy");
      let sites = "'1'";
      // let sites = "'WIH'";
      site.forEach(date => {
        sites += ",'" + date + "'";
      });
      console.log(sites);
      const berfordatalist = await this.berforadmintotal.datalistMonitouGroup(sites).toPromise();
      // console.log(berfordatalist['counts']);
      this.dataSet = berfordatalist;

      (this.dataSet).forEach(async data => {
        namelistw.push(data);

      });

      this.showdata = namelistw;

}

public async todaydata(){
  const namelistw = [];
  let site = this.sitename();
  site=this.sitename();
  let sites = "'1'";
      // let sites = "'WIH'";
  site.forEach(date => {
  sites += ",'" + date + "'";
      });
      console.log(sites);
  const datalist = await this.todayadmintotal.admintoday(sites).toPromise();
    this.dataSet=datalist;
  (this.dataSet).forEach(async data => {
      namelistw.push(data);
    });
  this.showdata=namelistw;
}
//增加的賬號
public async IncreAdmin(){
  const namelistw = [];
  let site = this.sitename();
  site=this.sitename();
  let sites = "'1'";
      // let sites = "'WIH'";
  site.forEach(date => {
  sites += ",'" + date + "'";
      });
      console.log(sites);
  const datalist = await this.todayadmintotal.IncreAdmintor(sites).toPromise();
    this.dataSet=datalist;
  (this.dataSet).forEach(async data => {
      namelistw.push(data);
    });
  this.showdata=namelistw;
}

//Apex One Status
public async OfficeScan(){
  let localsite = this.sitename();
  console.log("lllllll");
  console.log(localsite);
  console.log(this.site);
  this.site1=this.site.split("&")[0];
  if(this.site=='AgentRatio'){
    await this.offcanAgent(localsite);

  }else if(this.site=='NonAgentRatio'){
    await this.offcanAgentNo(localsite);

  }else if(this.site=='ServiceNormal'){
   await this.offcanService(localsite);
  }else if(this.site=='ServiceAbnormal'){
    await this.offcanServiceNo(localsite);
  }else if(this.site1=='PatternNormal'){
    console.log("ppppppppppppppppppp");

    this.viso=this.platformLocation.hash.split("viso=")[1];
    this.viso=this.viso.split(",");
    console.log(this.viso);
    await this.ofcversionQuery(this.viso);
}else if(this.site1=='PatternAbnormal'){
  this.viso=this.platformLocation.hash.split("viso=")[1];
  this.viso=this.viso.split(",");
  await this.ofcversionQueryNo(this.viso);
}
}


public async offcanAgent(site: string[] ) {
  const namelistw = [];
  const offcanAgentTotal= await this.eos.find({where:
      {and:[
        {Sitename: {inq: site}},
        {
          or:[{ ofcntrtscan: '4RUNNING' },
          { ofctmlisten: '4RUNNING' }]
        }
        ]}}).toPromise();
        console.log(offcanAgentTotal);
        this.dataSet= offcanAgentTotal;
        (this.dataSet).forEach(async element => {
          namelistw.push(element);
        });
        this.showdata=namelistw;
  // const Total = offcanAgentTotal.count;
  // const OffcanTotal = await this.eos.find({where:{Sitename: {inq: site}}}).toPromise();
  // const offcanTotal = OffcanTotal.count;
  // const datalist = [Total, offcanTotal];
  // return datalist;

}


public async offcanAgentNo(site: string[] ) {
  const namelistw = [];
  const offcanAgentTotal= await this.eos.find({where:
      {and:[
        {Sitename: {inq: site}},
        {
          or:[{ ofcntrtscan: ' ' },
          { ofctmlisten: ' ' }]
        }
        ]}}).toPromise();

        this.dataSet= offcanAgentTotal;
        (this.dataSet).forEach(async element => {
          console.log(Object.values(element));
          namelistw.push(element);
        });
        this.showdata=namelistw;
  // const Total = offcanAgentTotal.count;
  // const OffcanTotal = await this.eos.find({where:{Sitename: {inq: site}}}).toPromise();
  // const offcanTotal = OffcanTotal.count;
  // const datalist = [Total, offcanTotal];
  // return datalist;

}


public async offcanService(site: string[] ) {
  const namelistw = [];
  const offcanAgentTotal = await this.eos.find({where:{
    and: [
      { Sitename: {inq: site} },
      { ofcntrtscan: '4RUNNING' },
      { ofctmlisten: '4RUNNING' }
    ]
  }}).toPromise();
  this.dataSet= offcanAgentTotal;
  (this.dataSet).forEach(async element => {
    namelistw.push(element);
  });
  this.showdata=namelistw;
}
public async offcanServiceNo(site: string[] ) {
  const namelistw = [];
  const offcanAgentTotal = await this.eos.find({where:{
    and: [
      { Sitename: {inq: site} },
      { ofcntrtscan: ' ' },
      { ofctmlisten: ' ' }
    ]
  }}).toPromise();
  this.dataSet= offcanAgentTotal;
  (this.dataSet).forEach(async element => {
    namelistw.push(element);
  });
  this.showdata=namelistw;
}

//版本查詢
public  ofcversionQuery(inviso: string[]): Promise<any>  {
  return new Promise<any> (async (resolve, reject) => {
    const ofcversionlist: string[] = [];
    const namelistw = [];
    const invi=[];
    // invi=this.inviso[];
    let site=this.sitename();
    // console.log("000000000000000");
    // console.log(inviso);
    // console.log(site);
    // // let invisos = "'1'";
    // let inviso = this.inviso.split(',');
    // inviso.forEach(async date => {
    //   invisos += ",'" + date + "'";
    // });
    // inviso=['915', '913', '917'];
    const ofcversion = await this.eos.find({where:{
      and:[{Sitename: {inq: site}},
      {ofcversion:{inq:inviso}}]
    }}).toPromise();
    console.log(ofcversion);
    this.dataSet=ofcversion;
    // const ofcversion = await this.ofcversion.find().toPromise();
    (this.dataSet).forEach(async data => {
      namelistw.push(data);
      // ofcversionlist.push(Object.values(data).toString());
    });
    this.showdata=namelistw;
    // resolve(ofcversionlist);
  });
}

public  ofcversionQueryNo(inviso: string[]): Promise<any>  {
  return new Promise<any> (async (resolve, reject) => {
    const ofcversionlist: string[] = [];
    const namelistw = [];
    const invi=[];
    // invi=this.inviso[];
    let site=this.sitename();
    // console.log("000000000000000");
    // console.log(inviso);
    // console.log(site);
    // // let invisos = "'1'";
    // let inviso = this.inviso.split(',');
    // inviso.forEach(async date => {
    //   invisos += ",'" + date + "'";
    // });
    // inviso=['915', '913', '917'];
    // const ofcversion = await this.eos.find({where:{
    //   and:[{Sitename: {inq: site}},
    //   {not:{ofcversion:{inq:inviso}}}]
    // }}).toPromise();
    const ofcversion = await this.eos.find({where:{
      and:[{Sitename: {inq: site}},
     {ofcversion:{nin:inviso}}]
    }}).toPromise();
    console.log("lllllllllllllllllddddddd");
    console.log(ofcversion);
    this.dataSet = ofcversion;
    // const ofcversion = await this.ofcversion.find().toPromise();
    (this.dataSet).forEach(async data => {
      namelistw.push(data);
      // ofcversionlist.push(Object.values(data).toString());
    });
    this.showdata=namelistw;
    // resolve(ofcversionlist);
  });
}












   async onRoute() {
   //獲取路由傳值
   await this.activedRouter.params.subscribe((res) => {
   this.activedRouter.queryParams.subscribe((params: Params) => {

    const searchType = params['type'];

    const menu = params['menu'];
  //localStorage.setItem('menu',menu);
    console.log(searchType);
    console.log('menu:', menu);
  });
    });
  }





}
