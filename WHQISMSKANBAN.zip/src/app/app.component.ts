import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ConfigloadService } from 'src/app/service/configservice/configload.service';
import { LoopBackConfig } from './service/api/lb.config';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'WHQISMSkanban';
    constructor(
      private configureload: ConfigloadService,
    ) {

    }
    public ngOnInit(): void {
      LoopBackConfig.setBaseURL(this.configureload.getSpecificConfigure('datasources').urlAPI);

    }
}
