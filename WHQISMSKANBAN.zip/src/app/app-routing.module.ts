import { NgModule } from '@angular/core';
import { Routes, RouterModule, Route } from '@angular/router';
import { LoginindexComponent } from './UIshows/loginindex/loginindex.component';
import { HomeindexComponent } from './UIshows/homeindex/homeindex.component';
import { TabIndexComponent } from './RawDataList/tab-index/tab-index.component';


const fallbackRoute: Route = { path: '**', component: LoginindexComponent };

const routes: Routes = [

  {path: '', redirectTo: 'login', pathMatch: 'full'},//配置路由
  {path: 'login', component: LoginindexComponent},
  {path: 'main', component: HomeindexComponent},
  {path: 'tabindex', component: TabIndexComponent},
  fallbackRoute

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
