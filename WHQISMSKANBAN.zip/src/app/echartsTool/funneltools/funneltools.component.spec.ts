import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FunneltoolsComponent } from './funneltools.component';

describe('FunneltoolsComponent', () => {
  let component: FunneltoolsComponent;
  let fixture: ComponentFixture<FunneltoolsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FunneltoolsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FunneltoolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
