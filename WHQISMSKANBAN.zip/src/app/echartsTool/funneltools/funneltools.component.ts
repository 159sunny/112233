import { Component, OnInit, Input, SimpleChanges, OnChanges} from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-funneltools',
  templateUrl: './funneltools.component.html',
  styleUrls: ['./funneltools.component.scss']
})
export class FunneltoolsComponent implements OnInit, OnChanges {
  @Input() dataBL: any;
  @Input() titledata: any;
  @Input() datanum: any;
  @Input() height: any;
  @Input() offsion: any;


  constructor() { }
  changeChart: any;
  // height = 'windversion';

  // // // ==============线条参数参数设置start==============>>>>>>
  // data = [78, 60, 60, 70, 69];
  // titlename = ['Win10', 'Win2008', 'Win2019', 'Win2016'];
  // valdata = [500, 234, 234, 523, 345];
  // // // <<<<<================线条参数参数设置 end==================================



  chartOption: EChartOption = {};


  ngOnInit() {

  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.hasOwnProperty('titledata')) {
      if (this.titledata === undefined) {
      return;
      }
    }
    if (changes.hasOwnProperty('datanum')) {
      if (this.datanum === undefined) {
      return;
      }
    }
    if (changes.hasOwnProperty('dataBL')) {
      if (this.dataBL === undefined) {
      return;
      }
    }


    this.changeChart = {
         // =================line start=======================>>>>>>>>>>>
        grid: {
          left: '3%',
          right: '5%',
          top: '0%',
          bottom: '0%',
          containLabel: true
      },
      xAxis: {
          show: false,
          boundaryGap: [0, 0.8]
      },
      yAxis: [ {

          show: true,
          data: this.titledata,
          inverse: true,
          axisLine: {
              show: false
          },
          splitLine: {
              show: false
          },
          axisTick: {
              show: false
          },
          axisLabel: {
              textStyle: {
                fontSize : 15,

                color: function(value, index) {
                      const myColor = ['rgb(136, 187, 245)', '#EEA9B8', '#56D0E3', '#F8B448', '#8B78F6', '#BF3EFF'];
                      const num = myColor.length;
                      return myColor[index % num];
                  }
              },
              formatter: function(value, index) {
                  return [
                      '{title|' + value + '} '
                  ].join('\n');
              },
              rich: {}
          },

      }, {
          show: true,
          inverse: true,
          data: this.datanum,
          axisLabel: {
              textStyle: {
                fontSize : 15,
                color: function(value, index) {
                      const myColor = ['rgb(136, 187, 245)', '#EEA9B8', '#56D0E3', '#F8B448', '#8B78F6','#BF3EFF'];
                      const num = myColor.length;
                      return myColor[index % num];
                  }
              }
          },
          axisLine: {
              show: false
          },
          splitLine: {
              show: false
          },
          axisTick: {
              show: false
          },

      }],
      series: [{
          type: 'bar',
          yAxisIndex: 0,
          data: this.dataBL,
          barWidth: 15,
          itemStyle: {
              normal: {
                  barBorderRadius: 20,
                  color: function(params) {
                      const myColor = ['rgb(136, 187, 245)', '#EEA9B8', '#56D0E3', '#F8B448', '#8B78F6','#BF3EFF' ];
                      const num = myColor.length;
                      return myColor[params.dataIndex % num];
                  },
              }
          },
          label: {
              normal: {
                  show: true,
                  position: 'inside',
                  formatter: '{c}%',

                  textStyle: {
                    fontSize : 12

                  }
              }
          },
      }]
      // <<<<<=====================line end=============================
    };
  }

  async onChartInit(params) {
    //當前點擊的名字為
    // let site =e.currentTarget.previousElementSibling.innerHTML;
    const listbarname = params.name;
    console.log(params);
    let check: any;
    // title = ['AgentRatio', 'AgentAbRatio', 'ServiceNormal', 'ServiceAbnormal', 'PatternNormal', 'PatternAbnormal'];
    if ( listbarname == 'AgentRatio'|| listbarname =='NonAgentRatio'||listbarname=='ServiceNormal'|| listbarname == 'ServiceAbnormal'||listbarname == 'PatternNormal'||listbarname == 'PatternAbnormal') {
      check = 8;
      if(listbarname == 'AgentRatio'|| listbarname =='NonAgentRatio'||listbarname=='ServiceNormal'|| listbarname == 'ServiceAbnormal'){
        window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname);

      }else if(listbarname == 'PatternNormal'||listbarname == 'PatternAbnormal'){
        window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname+"&"+"viso="+this.offsion);
      }
      console.log(this.offsion);
      } else{
      check = 4;
      window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname);
    }
    // console.log("點擊當前的name為："+params.name);
    // window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname+"&"+"viso="+this.offsion);
  }

}
