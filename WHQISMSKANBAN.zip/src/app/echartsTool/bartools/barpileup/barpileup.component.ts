import { Component, OnInit, Input, SimpleChanges, OnChanges, RenderComponentType } from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-barpileup',
  templateUrl: './barpileup.component.html',
  styleUrls: ['./barpileup.component.scss']
})
export class BarpileupComponent implements OnInit, OnChanges {
  @Input() rawtotal: any;
  @Input() actualtotal: any;
  @Input() downtotal: any;
  @Input() uptotal: any;
  @Input() upbarstatus: any;
  @Input() downbarstatus: any;
  changeChart: any;
  chartOption: EChartOption = {
  //   tooltip : {
  //     trigger: 'item',
  //     // color: 'rgb(255,255,255)',
  //     formatter: {
  //       componentType: 'series',
  //       seriesType: 1

  //     },
  //   },
  //   color: ['#7CCFCC', '#7CCFCC', '#009DFC', 'rgb(245, 61, 14)'],
  //   legend: {
  //       type: 'scroll',
  //       orient: 'vertical',
  //       itemHeight: 12,
  //       itemWidth: 12,
  //       itemGap: 2,
  //       right: 10,
  //       top: 5,
  //       bottom: 20,
  //       textStyle: {
  //         color: 'rgb(255,255,255)',
  //         fontSize: 10
  //         },
  //       data: ['原始数量', '减少数量', '增加数量']
  //   },
  //   grid: {
  //       left: '15%',
  //       right: '3%',
  //       bottom: '0%',
  //       top: '8%',
  //       height: '35%',
  //       width: '60%',
  //       containLabel: true
  //   },
  //   xAxis : [
  //       {
  //         axisLine: {
  //           lineStyle: {
  //               color: '#ccc'
  //           }
  //       },
  //           type : 'category',
  //           data : ['账号变化']
  //       }
  //   ],
  //   yAxis : [
  //       {
  //         axisLine: {
  //           lineStyle: {
  //               color: '#ccc'
  //           }
  //       },
  //           type : 'value'
  //       }
  //   ],
  //   series : [
  //       {
  //           name: '原始数量',
  //           type: 'bar',
  //           label: {
  //             normal: {
  //                 show: true,
  //                 position: 'inside',
  //                 fontSize: 16
  //             }
  //         },
  //           data: [0]
  //       },
  //       {
  //           name: '差异前数量',
  //           type: 'bar',
  //           stack: '变化状况',
  //           label: {
  //             normal: {
  //                 show: true,
  //                 position: 'inside',
  //                 fontSize: 16
  //             }
  //         },
  //           data: [0]
  //       },
  //       {
  //           name: '减少数量',
  //           stack: '变化状况',
  //           type: 'bar',
  //           label: {
  //             normal: {
  //                 show: false,
  //                 position: 'inside',
  //                 fontSize: 16
  //             }
  //         },
  //           data: [0],
  //       },
  //       {
  //         name: '增加数量',
  //         stack: '变化状况',
  //         type: 'bar',
  //         label: {
  //           normal: {
  //               show: false,
  //               position: 'inside',
  //               fontSize: 16
  //           }
  //       },
  //         data: [0],
  //     }
  // ]
  };

  ngOnChanges(changes: SimpleChanges): void {
    // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    // Add '${implements OnChanges}' to the class.
    this.changeChart = {
      tooltip : {
        trigger: 'axis',
        color: 'rgb(255,255,255)',
        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
          type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
      },
      formatter(datas) {
                // tslint:disable-next-line: one-variable-per-declaration
                let res = datas[0].name + '<br/>', val;
                for ( let i = 0, length = datas.length; i < length; i++) {
                    // tslint:disable-next-line: triple-equals
                    if (i != 1) {
                      val = datas[i].value;
                      // tslint:disable-next-line: max-line-length
                      res += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + datas[i].color + '"></span>';
                      res += datas[i].seriesName + '：' + val + '<br/>';
                    }
                  }
                return res;
             }
      },
      color: ['#7CCFCC', '#02548a', '#009DFC', 'rgb(245, 61, 14)'],
      legend: {
          type: 'scroll',
          orient: 'vertical',
          itemHeight: 12,
          itemWidth: 12,
          itemGap: 2,
          right: 10,
          top: 5,
          bottom: 20,
          textStyle: {
            color: 'rgb(255,255,255)',
            fontSize: 13
            },
          // data: ['原始数量', '减少数量', '增加数量']
          data: ['Original','today', 'Decreases', 'Increase']
      },
      grid: {
          left: '15%',
          right: '3%',
          bottom: '0%',
          top: '4%',
          height: '93%',
          width: '55%',
          containLabel: true
      },
      xAxis : [
          {
            axisLine: {
              lineStyle: {
                  color: '#ccc'
              }
          },
              type : 'category',
              // data : ['账号变化']
              data : ['Account Trends']
          }
      ],
      yAxis : [
          {
            axisLine: {
              lineStyle: {
                  color: '#ccc'
              }
          },
              type : 'value'
          }
      ],
      series : [
          {
              // name: '原始数量',
              name: 'Original',
              type: 'bar',
              label: {
                normal: {
                    show: true,
                    position: 'inside',
                    fontSize: 16
                }
            },
              data: [this.rawtotal]
          },
          {
              name: 'today',
              type: 'bar',
              // stack: '变化状况',
              label: {
                normal: {
                    show: true,
                    position: 'inside',
                    fontSize: 16
                }
            },
              data: [this.actualtotal]
          },
          {
              // name: '减少数量',
              name: 'Decreases',
              // stack: '变化状况',
              type: 'bar',
              label: {
                normal: {
                    // show: this.downbarstatus,
                    show: true,
                    position: 'inside',
                    fontSize: 16
                }
            },
              data: [this.downtotal],
          },
          {
            // name: '增加数量',
            name: 'Increase',
            // stack: '变化状况',
            type: 'bar',
            label: {
              normal: {
                  // show: this.upbarstatus,
                  show: true,
                  position: 'inside',
                  fontSize: 16
              }
          },
            data: [this.uptotal],
        }
    ]
    };
  }
  constructor() { }

  ngOnInit() {
  }

  async onChartInit(params) {
    //當前點擊的名字為
    const listbarname = params.name;
    const listyue = params.seriesName;
    const clickNow = params.componentIndex;
    console.log(params);

    // console.log("點擊當前的name為："+params.name);

    let check = 7;
    window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname+"&"+"clickNow="+clickNow);
  }

}
