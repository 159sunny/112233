import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarpileupComponent } from './barpileup.component';

describe('BarpileupComponent', () => {
  let component: BarpileupComponent;
  let fixture: ComponentFixture<BarpileupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarpileupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarpileupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
