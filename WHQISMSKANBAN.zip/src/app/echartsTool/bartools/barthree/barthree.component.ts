import { Component, OnInit, Input, SimpleChanges, OnChanges} from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-barthree',
  templateUrl: './barthree.component.html',
  styleUrls: ['./barthree.component.scss']
})
export class BarthreeComponent implements OnInit, OnChanges {
// 參數
@Input() fottitlelist: any;
@Input() fottitle1data: any;
@Input() fottitle2data: any;
@Input() fottitle3data: any;
@Input() servertotal: any;
// fottitlelist = ['product', 'WHQ', 'WZS', 'WKS', 'WCQ', 'WOK' , 'WCD'];
// fottitle1data = ['8月份', 41.1, 30.4, 90, 50, 70 , 20];
// fottitle2data = ['9月份', 86.5, 92.1, 60, 60, 90 , 40];
// fottitle3data = ['10月份', 86.5, 92.1, 70, 55, 42 , 80];

myChart: any;
changeChart: any;
chartOption: EChartOption = {
    //   color: ['rgb(150,234,225)', 'rgb(0,157,252)', 'rgb(170,170,170)', 'rgb(43,103,111)', 'rgb(67,155,270)'],
    //   legend: {
    //     type: 'scroll',
    //     orient: 'vertical',
    //     itemHeight: 12,
    //     itemWidth: 12,
    //     itemGap: 2,
    //     right: 2,
    //     top: -1,
    //     // bottom: 20,
    //     textStyle: {
    //       color: 'rgb(255,255,255)',
    //       fontSize: 10
    //       }
    //       },
    //   tooltip: {},
    //   dataset: {
    //       source: [

    //       ]
    //   },
    //   xAxis: [
    //       {
    //         type: 'category',
    //         gridIndex: 0,
    //         nameTextStyle: {
    //           color: '#ccc',
    //           fontSize: 13
    //       },
    //       axisLine: {
    //           lineStyle: {
    //               color: '#ccc'
    //           }
    //       },
    //       splitLine: {
    //           show: false
    //       }
    //       }

    //   ],
    //   yAxis: [
    //       {
    //         gridIndex: 0,
    //         nameTextStyle: {
    //           color: '#ccc',
    //           fontSize: 10
    //       },
    //       axisLine: {
    //           lineStyle: {
    //               color: '#ccc'
    //           }
    //       },
    //       splitLine: {
    //           show: false
    //       }
    //       }
    //   ],
    //   grid: {
    //       left: '0%',
    //       right: '10%',
    //       height: '70%',
    //       top: '20%',
    //       bottom: '2%',
    //       containLabel: true
    // },
    //   series: [
    //       // These series are in the first grid.
    //       {type: 'bar', seriesLayoutBy: 'row'},
    //       {type: 'bar', seriesLayoutBy: 'row'},
    //       {type: 'bar', seriesLayoutBy: 'row'},
    //   ]
};

 ngOnChanges(changes: SimpleChanges): void {
  //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
  //Add '${implements OnChanges}' to the class.
  // console.log('this.fottitlelist');
  // console.log(this.fottitlelist);
  // console.log(this.fottitle1data);
  // console.log(this.fottitle2data);
  // console.log(this.fottitle3data);


  // console.log(changes);
  // console.log('----------');
  if (changes.hasOwnProperty('fottitlelist')) {
    if (this.fottitlelist === undefined) {
    return;
    }
  }
  if (changes.hasOwnProperty('fottitle1data')) {
    if (this.fottitle1data === undefined) {
    return;
    }
  }
  if (changes.hasOwnProperty('fottitle2data')) {
    if (this.fottitle2data === undefined) {
    return;
    }
  }
  if (changes.hasOwnProperty('fottitle3data')) {
    if (this.fottitle3data === undefined) {
    return;
    }
  }


  // console.log(this.fottitle2data);
  // console.log(this.fottitle3data);
  this.changeChart = {
      // color: ['rgb(150,234,225)', 'rgb(0,157,252)', 'rgb(170,170,170)', 'rgb(43,103,111)', 'rgb(67,155,270)'],
      color: ['#008B8B', 'rgb(0,157,252)', '#836FFF', 'rgb(43,103,111)', 'rgb(67,155,270)'],
      legend: {
        type: 'scroll',
        orient: 'vertical',
        itemHeight: 12,
        itemWidth: 12,
        itemGap: 2,
        right: 2,
        top: -1,

        // bottom: 20,
        textStyle: {
          color: 'rgb(255,255,255)',
          fontSize: 13
          }
          },
      tooltip: {},
      dataset: {
          source: this.servertotal
      },
      xAxis: [
          {
            type: 'category',
            gridIndex: 0,
            nameTextStyle: {
              color: '#ccc',
              fontSize: 13
          },
          axisLine: {
              lineStyle: {
                  color: '#ccc'
              }
          },
          splitLine: {
              show: false
          }
          }

      ],
      yAxis: [
          {
            gridIndex: 0,
            nameTextStyle: {
              color: '#ccc',
              fontSize: 10
          },
          axisLine: {
              lineStyle: {
                  color: '#ccc'
              }
          },
          splitLine: {
              show: false
          }
          }
      ],
      grid: {
          left: '0%',
          right: '10%',
          height: '70%',
          top: '20%',
          containLabel: true
    },
      series: [
          // These series are in the first grid.
          {
            type: 'bar',
            barMinHeight: 10,
            seriesLayoutBy: 'row',
            label: {
              normal: {
                  show: true,
                  position: 'inside'
              }
            }
          },
          {
            type: 'bar',
            barMinHeight: 10,
            seriesLayoutBy: 'row',
            label: {
              normal: {
                  show: true,
                  position: 'inside'
              }
            }
          },
          {
            type: 'bar',
            barMinHeight: 10,
            seriesLayoutBy: 'row',
            label: {
              normal: {
                  show: true,
                  position: 'inside'
              }
            }
          },
      ]
  };
}
  constructor() { }

  ngOnInit() {

  //   myChart = echarts.init(document.getElementById('main'));
  //   myChart.on('click', function (params) {
  //     console.log(params);
  // });

  }


  async onChartInit(params) {
    //當前點擊的名字為
    const listbarname = params.name;
    const listyue = params.seriesName;
    const clickNow = params.componentIndex;
    console.log(params);

    console.log("點擊當前的name為："+listyue);

    let check = 1;
    window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname+"&"+"clickNow="+clickNow+"&"+"month="+listyue);
  }


  // resizeChart() {
  //   if (this.echartsIntance) {
  //     this.echartsIntance.resize();
  //   }
  // }

}
