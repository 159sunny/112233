import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarthreeComponent } from './barthree.component';

describe('BarthreeComponent', () => {
  let component: BarthreeComponent;
  let fixture: ComponentFixture<BarthreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarthreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarthreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
