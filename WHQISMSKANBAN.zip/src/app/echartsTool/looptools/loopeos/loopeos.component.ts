import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-loopeos',
  templateUrl: './loopeos.component.html',
  styleUrls: ['./loopeos.component.scss']
})
export class LoopeosComponent implements OnInit, OnChanges {
  @Input() actualresult: any;
  @Input() total: any;
  @Input() totals: any;
  @Input() radius: any;
  @Input() center: any;
  changeChart: any;
  chartOption: EChartOption = {
  //   color: ['	#0AA2E5', '#224054'],
  //   // grid: {
  //   //   height: '10%',
  //   //   top: '1%',
  //   //   bottom: '0%',
  //   //   containLabel: true
  //   // },
  //   series: [
  //     {
  //         name: '',
  //         type: 'pie',
  //         radius: ['80%', '5%'],
  //         // center: [ '50%' , '16%'],
  //         avoidLabelOverlap: true,
  //         data: [
  //             {
  //                 value: [],
  //                 name: '已更新',
  //                 label: {
  //                     normal: {
  //                         formatter: '{c}\n\n',
  //                         textStyle: {
  //                           fontSize: '10',
  //                           color: 'white',
  //                           // fontWeight: 'normal'
  //                         },
  //                         show: true,
  //                         position: 'center'
  //                     },
  //                 }
  //             },
  //             {
  //                 value: [],
  //                 name: [],
  //                 label: {
  //                     normal: {
  //                          formatter: '\n-----\n{b}',
  //                          textStyle: {
  //                           fontSize: '10',
  //                           color: 'white',
  //                           // fontWeight: 'normal'
  //                         },
  //                         show: true,
  //                         position: 'center'
  //                     },
  //                 }
  //             }
  //         ]
  //     }
  // ]
  };

  ngOnChanges(changes: SimpleChanges): void {

      if (changes.hasOwnProperty('actualresult')) {
        if (this.actualresult === undefined) {
        return;
        }
      }

      if (changes.hasOwnProperty('total')) {
        if (this.total === undefined) {
        return;
        }
      }

      if (changes.hasOwnProperty('totals')) {
        if (this.totals === undefined) {
        return;
        }
      }

      // console.log(this.actualresult);
      // console.log(this.total);
      // console.log(this.totals);
      const options = {


        color: ['	#0AA2E5', '#224054'],
        // grid: {
        //   // height: '30%',
        //   top: '-5%',
        //   bottom: '0%',
        //   containLabel: true
        // },
        series: [
          {
              name: '',
              type: 'pie',
              radius: this.radius,
              center: this.center,
              avoidLabelOverlap: true,
              data: [
                  {
                      value: this.actualresult,
                      name: '已更新',
                      label: {
                          normal: {
                              formatter: '\n{c}\n\n\n',
                              textStyle: {
                                fontSize: '10',
                                color: 'white',
                                // fontWeight: 'normal'
                              },
                              show: true,
                              position: 'center'
                          },
                      }
                  },
                  {
                      value: this.total,
                      name: this.totals,
                      label: {
                          normal: {
                               formatter: '\n\n-----\n{b}\n\n',
                               textStyle: {
                                fontSize: '10',
                                color: 'white',
                                // fontWeight: 'normal'
                              },
                              show: true,
                              position: 'center'
                          },
                      }
                  }
              ]
          }
      ]

        };

      this.changeChart = JSON.parse(JSON.stringify(options));
    }

  constructor() { }

  ngOnInit() {
  }

}
