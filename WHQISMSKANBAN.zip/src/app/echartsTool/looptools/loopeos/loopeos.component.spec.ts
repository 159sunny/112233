import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoopeosComponent } from './loopeos.component';

describe('LoopeosComponent', () => {
  let component: LoopeosComponent;
  let fixture: ComponentFixture<LoopeosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoopeosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoopeosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
