import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-loopapp',
  templateUrl: './loopapp.component.html',
  styleUrls: ['./loopapp.component.scss']
})
export class LoopappComponent implements OnInit, OnChanges {
  @Input() GXtotal: any;
  @Input() apptotal: any;
  @Input() QTtotal: any;
  changeChart: any;
  chartOption: EChartOption = {
  //   color: ['#224054', '#0AA2E5'],
  //   grid: {
  //     height: '10%',
  //    top: '0%',
  //    bottom: '0%',
  //    containLabel: true
  // },
  //   series: [
  //     {
  //         name: '',
  //         type: 'pie',
  //         // radius: ['50%', '70%'],
  //         radius: ['90%', '80%'],
  //         // center: [ '40%' , '30%'],
  //         avoidLabelOverlap: true,
  //         data: [
  //             {
  //                 value: 50,
  //                 name: '已更新',
  //                 label: {
  //                     normal: {
  //                         formatter: '{c}\n\n',
  //                         textStyle: {
  //                           fontSize: '6',
  //                           color: 'white',
  //                           // fontWeight: 'normal'
  //                         },
  //                         show: true,
  //                         position: 'center'
  //                     },
  //                 }
  //             },
  //             {
  //                 value: 250,
  //                 name: '300',
  //                 label: {
  //                     normal: {
  //                          formatter: '\n-----\n{b}',
  //                          textStyle: {
  //                           fontSize: '6',
  //                           color: 'white',
  //                           // fontWeight: 'normal'
  //                         },
  //                         show: true,
  //                         position: 'center'
  //                     },
  //                 }
  //             }
  //         ]
  //     }
  // ]

  };
  ngOnChanges(changes: SimpleChanges): void {
    // if (changes.hasOwnProperty('showtitles')) {
    //   if (this.showtitles === undefined) {
    //   return;
    //   }
    // }
    const options = {
      color: ['#0AA2E5', '#224054'],
      grid: {
        height: '10%',
        top: '0%',
        bottom: '0%',
        containLabel: true
      },
      series: [
        {
            name: '',
            type: 'pie',
            // radius: ['50%', '70%'],
            radius: ['100%', '85%'],
            // center: [ '40%' , '30%'],
            avoidLabelOverlap: true,
            data: [
                {
                    value: this.GXtotal,
                    name: '更新',
                    label: {
                        normal: {
                            formatter: '{c}\n\n',
                            textStyle: {
                              fontSize: '10',
                              color: 'white',
                              // fontWeight:8 'normal'
                            },
                            show: true,
                            position: 'center'
                        },
                    }
                },
                {
                    value: this.QTtotal,
                    name: this.apptotal,
                    label: {
                        normal: {
                             formatter: '\n-----\n{b}',
                             textStyle: {
                              fontSize: '10',
                              color: 'white',
                              // fontWeight: 'normal'
                            },
                            show: true,
                            position: 'center'
                        },
                    }
                }
            ]
        }
    ]
    };

    this.changeChart = JSON.parse(JSON.stringify(options));


  }
  constructor() { }

  ngOnInit() {
  }



}
