import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoopappComponent } from './loopapp.component';

describe('LoopappComponent', () => {
  let component: LoopappComponent;
  let fixture: ComponentFixture<LoopappComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoopappComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoopappComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
