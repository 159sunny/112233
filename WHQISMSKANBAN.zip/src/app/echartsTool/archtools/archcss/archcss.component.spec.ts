import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchcssComponent } from './archcss.component';

describe('ArchcssComponent', () => {
  let component: ArchcssComponent;
  let fixture: ComponentFixture<ArchcssComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchcssComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchcssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
