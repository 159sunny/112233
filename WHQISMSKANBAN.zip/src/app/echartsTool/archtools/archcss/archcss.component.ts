import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-archcss',
  templateUrl: './archcss.component.html',
  styleUrls: ['./archcss.component.scss']
})
export class ArchcssComponent implements OnInit {
  title: any = '3个賬號以下';
  b1ratio: any = '90';
  b1: any = 200;
  constructor() { }

  ngOnInit() {
  }

}
