import { Component, OnInit, Input, OnChanges, SimpleChanges} from '@angular/core';
import { EChartOption } from 'echarts';

@Component({
  selector: 'app-piecharts',
  templateUrl: './piecharts.component.html',
  styleUrls: ['./piecharts.component.scss']
})
export class PiechartsComponent implements OnInit,  OnChanges {
  @Input() radiusdata: any;
  @Input() centerdata: any;
  @Input() showtitles: any;
  @Input() datashows: any;
  changeChart: any;

  // 初始化
  chartOption: EChartOption = {
  //   color: ['rgb(36,142,255)', 'rgb(115,114,243)', 'rgb(125,207,96)', 'rgb(221, 218, 21)', 'rgb(89,249,241)'],
  //   legend: {
  //     type: 'scroll',
  //             orient: 'vertical',
  //             right: 10,
  //             top: 0,
  //             bottom: 0,
  //             textStyle: {
  //               fontSize: 8,
  //               color: 'rgb(255,255,255)',
  //             },
  //     data: []
  //   },
  //   text: {
  //     color: 'red',
  //   },
  //   series: [
  //     {
  //         type: 'pie',
  //         radius: [],
  //         center: [],
  //         label: {
  //           normal: {
  //               formatter: '{d}%',
  //               rich: {
  //                   b: {
  //                       fontSize: 13,
  //                       lineHeight: 20,
  //                       align: 'center'
  //                   },
  //                   d: {
  //                     fontSize: 20,
  //                     lineHeight: 20,
  //                     align: 'center'
  //                   },
  //                   per: {
  //                       color: '#eee',
  //                   }
  //               }
  //           }
  //       },
  //         data: []
  //     }
  // ]
  };

  // 重新加載
  ngOnChanges(changes: SimpleChanges): void {
    // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    // Add '${implements OnChanges}' to the class.
    if (changes.hasOwnProperty('showtitles')) {
      if (this.showtitles === undefined) {
      return;
      }
    }
    if (changes.hasOwnProperty('datashows')) {
      if (this.datashows === undefined) {
      return;
      }
    }
    // console.log(this.datashows);
    this.changeChart = {
        color: ['#FFB36E', '#9C79F9', 'rgb(125,207,96)', 'rgb(221, 218, 21)', 'rgb(89,249,241)'],
        legend: {
                  itemHeight: 12,
                  itemWidth: 18,
                  itemGap: 2,
                  type: 'scroll',
                  orient: 'vertical',
                  right: 1,
                  top: 0,
                  bottom: 0,
                  textStyle: {
                    fontSize: 13,
                    color: 'rgb(255,255,255)',
                  },
          data: this.showtitles
        },
        text: {
          color: 'red',
        },
        series: [
          {
              type: 'pie',
              radius: this.radiusdata,
              center: this.centerdata,
              label: {
                normal: {
                    formatter: '{d|{d}%}\n{c|{c}}',
                    rich: {
                        d: {
                          fontSize: 10,
                          fontWeight: 'bold',
                          fontFamily: '微軟正黑體',
                          padding: 1,
                          // lineHeight: 10,
                          align: 'center'
                        },
                        c: {
                          fontWeight: 'bold',
                          padding: 0,
                          fontSize: 10,
                          fontFamily: '微軟正黑體',
                          color: '#FFF',
                        },
                        e: {
                          color: '#Fce',
                        }
                    }
                }
            },
              data: this.datashows
          }
      ]
    };
  }
  constructor() { }

  ngOnInit() {
  }



  async onChartInit(params) {
    //當前點擊的名字為
    const listbarname = params.name;
    const listyue = params.seriesName;
    const clickNow = params.dataIndex;
    console.log(params);

    // console.log("點擊當前的name為："+params.name);

    let check = 6;
    window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+listbarname+"&"+"clickNow="+clickNow);
  }

}
