import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
// import { UserIFO } from '../../modulesCode/objectmodules/UserIFO';
import { UserIFOService } from 'src/app/modulesCode/objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';




// import { querySite } from '../../modulesCode/objectmodules/querySite';
@Component({
  selector: 'app-homeindex',
  templateUrl: './homeindex.component.html',
  styleUrls: ['./homeindex.component.scss']
})
export class HomeindexComponent implements OnInit, OnDestroy {
  public dates: any;
  stie: any = [];
  sitename: any;
  userpower: any;
  UserGroup: any;
  localoff = true;
  public userIFO: Subscription;




  // selectedValue: any = false;
  constructor(
    private router: Router,
    private userInfoService: UserIFOService
    ) {

     }

    public ngOnDestroy(): void {
      if (this.userIFO !== undefined) {
        this.userIFO.unsubscribe();
      }
    }
 async ngOnInit() {
    this.initializepage();
    window.onresize = function() {
      const windowWidth = document.documentElement.offsetWidth;
      const windowHeight = document.documentElement.offsetHeight;
      document.getElementById('indexbody').style.width = windowWidth + 'px';
      document.getElementById('indexbody').style.height = windowHeight + 'px';
      document.getElementById('footer').style.width = windowWidth + 'px';
      document.getElementById('footer').style.height = windowHeight * 0.1 + 'px';
      document.getElementById('mianlifte').style.width = windowWidth * 0.7 + 'px';
      document.getElementById('mianlifte').style.height = windowHeight * 0.9 + 'px';
      document.getElementById('mianrigth').style.width = windowWidth * 0.3 + 'px';
      document.getElementById('mianrigth').style.height = windowHeight * 0.9 + 'px';
    };
    await this.loadingindex();
    await this.site();
    await this.powers();
    await this.sx();
    // console.log(this.userpower)
    await this.userGroup();
    if ( this.UserGroup === 'IT') {
        const sitedate = await this.userpower.toString();
        const  siteall =  sitedate.split(',');
        if (siteall.length > 1) {
          siteall.push('All');
          // console.log(sitedate);
        }
        this.stie = siteall;
        // console.log(this.stie);
        // this.stie = await UserIFO.getUserSite();
    }
    if ( this.UserGroup === 'IT Supervisor') {

    }
    if ( this.UserGroup === undefined) {
       this.router.navigate(['/login']);
    }
    setInterval(() => {
      this.dates = new Date();
    }, 1000);



  }



  public loadingindex(){
    if (   window.localStorage['userpower'] !== undefined
    && window.localStorage['UserGroup'] !== undefined
    && window.localStorage['sitename'] !== undefined) {
      this.userInfoService.UserSite.next(window.localStorage['sitename']);
      this.userInfoService.UserGroup.next(window.localStorage['UserGroup']);
      this.userInfoService.Userpower.next(window.localStorage['userpower']);
    }
  }

  siteChange() {
    // this.isLoading = true;
    this.userInfoService.UserSite.next(this.sitename);
    window.localStorage['sitename'] = this.sitename;
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }


  // 获取userIfo相关信息
  public  userGroup(): void {
    const UserGroup = this.userInfoService.UserGroup
      .asObservable()
      .subscribe(async Group => {
        this.UserGroup = await Group;
        window.localStorage['UserGroup'] = this.UserGroup;
        // console.log('Site', this.userpower);
      }, error => {
        console.error(error);
      });
    if (this.userIFO !== undefined) {
      this.userIFO.add(UserGroup);
    } else {
      this.userIFO = UserGroup;
    }
  }

  public  powers(): void {
    const userpower = this.userInfoService.Userpower
      .asObservable()
      .subscribe(async power => {
        this.userpower = await power;
        window.localStorage['userpower'] = this.userpower;
        // console.log('Site', this.userpower);
      }, error => {
        console.error(error);
      });
    if (this.userIFO !== undefined) {
      this.userIFO.add(userpower);
    } else {
      this.userIFO = userpower;
    }
  }


  public  site(): void {
    const userpower = this.userInfoService.UserSite
      .asObservable()
      .subscribe(async Site => {
        this.sitename = await Site;
        window.localStorage['sitename'] = this.sitename;
        console.log(this.sitename);
        // console.log('Site', this.userpower);
      }, error => {
        console.error(error);
      });
    if (this.userIFO !== undefined) {
      this.userIFO.add(userpower);
    } else {
      this.userIFO = userpower;
    }
  }

  public initializepage() {
    const windowWidth = document.documentElement.offsetWidth;
    const windowHeight = document.documentElement.offsetHeight;
    document.getElementById('indexbody').style.width = windowWidth + 'px';
    document.getElementById('indexbody').style.height = windowHeight + 'px';
    document.getElementById('footer').style.width = windowWidth + 'px';
    document.getElementById('footer').style.height = windowHeight * 0.1 + 'px';
    document.getElementById('mianlifte').style.width = windowWidth * 0.7 + 'px';
    document.getElementById('mianlifte').style.height = windowHeight * 0.9 + 'px';
    document.getElementById('mianrigth').style.width = windowWidth * 0.3 + 'px';
    document.getElementById('mianrigth').style.height = windowHeight * 0.9 + 'px';
  }

//   myrefresh(){
//    window.location.reload();
// }
// setTimeout('myrefresh()',1000); //指定1秒刷新一次
  sx() {
    setTimeout( function () {
      location.reload();
      console.log( "5分鐘刷新一次頁面" );
    }, 1800000);
    console.log(new Date());
  }

}
