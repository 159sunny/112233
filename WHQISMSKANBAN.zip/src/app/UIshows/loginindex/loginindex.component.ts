import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { HttpClient } from '@angular/common/http';
import { ConfigloadService } from 'src/app/service/configservice/configload.service';
import { MessageModalComponent } from 'src/app/modulesCode/LoginModules/message-modal/message-modal.component';
import { ACVUserAuthorityApi } from '../../service/api/index';

import { UserIFOService } from 'src/app/modulesCode/objectmodules/user-ifo.service';



@Component({
  selector: 'app-loginindex',
  templateUrl: './loginindex.component.html',
  styleUrls: ['./loginindex.component.scss']
})
export class LoginindexComponent implements OnInit {
    @ViewChild(MessageModalComponent, {static: false})
    messageModal: MessageModalComponent;
    // user Msg
    domain: any;
    userid: any;
    password: any;

    isLoading: boolean = false;
    // Msg
    msgTitle: string = '';
    msgDetail: any = '';
    modalHeader: any = '';
    modalBody: any = '';


  constructor(
    private router: Router,
    private http: HttpClient,
    private configureload: ConfigloadService,
    private userquanxian: ACVUserAuthorityApi,
    private userifo: UserIFOService
  ) { }

  ngOnInit() {
  }
  login() {
    // console.log("sasddsad");
    const that = this;
    if (!that.domain || !that.userid || !that.password) {
        return;
    }
    // if (this.configureload.getSpecificConfigure('datasources')('urlLogin') != null) {
    that.isLoading = true;

    const key = '2b7e151628aed2a6abf7158809cf4f3c';
    const encrypted = CryptoJS.AES.encrypt(that.password, key);
    const ciphertext = encrypted.toString();
    const bytes = CryptoJS.AES.decrypt(ciphertext.toString(), key);
    // const plaintext = bytes.toString(CryptoJS.enc.Utf8);

    const data = {
            'domain': that.domain.toUpperCase(),
            'username': that.userid, // userID
            'password': ciphertext
        };
    that.http.post(this.configureload.getSpecificConfigure('datasources').urlLogin, data)
            .subscribe(res => {
                // console.log(res['user']['username']);
                this.userquanxian.find({where: { EmployeeID: that.userid }}).subscribe( data => {
                  const UserGroup: any = data[0];
                  // const sitesarrays = sites.split(',');
                  // console.log(sitesarrays);
                  if (UserGroup !== undefined) {
                      this.userifo.UserId.next(data[0]['EmployeeID']);
                      this.userifo.UserName.next(data[0]['UserName']);
                      this.userifo.UserSite.next(that.domain);
                      this.userifo.UserGroup.next(data[0]['UserGroup']);
                      this.userifo.Userpower.next(data[0]['Authority']);



                      // UserIFO.setUserId(data[0]['EmployeeID']);
                      // UserIFO.setUserName(data[0]['UserName']);
                      // UserIFO.setUserGroup(data[0]['UserGroup']);
                      // UserIFO.setUserpower(data[0]['Authority']);
                      // UserIFO.setUserSite(that.domain);
                      that.enterPage();
                  } else {
                    that.isLoading = false;
                    that.modalHeader = 'LOGIN Failed';
                    that.modalBody = 'No Authority!';
                    that.messageModal.show();
                  }
                  // const sites = data[0]['Authority'];
                  // const sitesarrays = sites.split(',');
                  // console.log(sitesarrays);
                });
                }, (err: any) => {
                  const errorMsg = '';
                  try {
                      const errorMsg = err.error.error.message;
                  } catch (error) {
                  }
                  that.isLoading = false;
                  that.modalHeader = 'LOGIN';
                  that.modalBody = 'Login failed!';
                  that.messageModal.show();
                  // console.log('Login failed!', errorMsg);
              });

        }



    // }
    // 進入主頁面
    enterPage( ) {
      this.router.navigate(['/main']);
    }
    setMsg(title: string = '', detail: any = '') {
      this.isLoading = false;
      this.msgTitle = title;
      this.msgDetail = detail;
  }
}
