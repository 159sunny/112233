/* tslint:disable */

declare var Object: any;
export interface V_TwoUltiomServertotalInterface {
  "ComputerName"?: string;
  "osversion"?: string;
  "updatedate"?: Date;
  "cpu"?: string;
  "memory"?: string;
  "hdddrivesname"?: string;
  "hddsize"?: string;
  "Sitename"?: string;
}

export class V_TwoUltiomServertotal implements V_TwoUltiomServertotalInterface {
  "ComputerName": string;
  "osversion": string;
  "updatedate": Date;
  "cpu": string;
  "memory": string;
  "hdddrivesname": string;
  "hddsize": string;
  "Sitename": string;
  constructor(data?: V_TwoUltiomServertotalInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_TwoUltiomServertotal`.
   */
  public static getModelName() {
    return "V_TwoUltiomServertotal";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_TwoUltiomServertotal for dynamic purposes.
  **/
  public static factory(data: V_TwoUltiomServertotalInterface): V_TwoUltiomServertotal{
    return new V_TwoUltiomServertotal(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_TwoUltiomServertotal',
      plural: 'V_TwoUltiomServertotals',
      path: 'V_TwoUltiomServertotals',
      idName: 'ComputerName',
      properties: {
        "ComputerName": {
          name: 'ComputerName',
          type: 'string'
        },
        "osversion": {
          name: 'osversion',
          type: 'string'
        },
        "updatedate": {
          name: 'updatedate',
          type: 'Date'
        },
        "cpu": {
          name: 'cpu',
          type: 'string'
        },
        "memory": {
          name: 'memory',
          type: 'string'
        },
        "hdddrivesname": {
          name: 'hdddrivesname',
          type: 'string'
        },
        "hddsize": {
          name: 'hddsize',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
