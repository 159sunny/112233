/* tslint:disable */

declare var Object: any;
export interface V_AutoOfcversionInterface {
  "ofcversion"?: string;
}

export class V_AutoOfcversion implements V_AutoOfcversionInterface {
  "ofcversion": string;
  constructor(data?: V_AutoOfcversionInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoOfcversion`.
   */
  public static getModelName() {
    return "V_AutoOfcversion";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoOfcversion for dynamic purposes.
  **/
  public static factory(data: V_AutoOfcversionInterface): V_AutoOfcversion{
    return new V_AutoOfcversion(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoOfcversion',
      plural: 'V_AutoOfcversions',
      path: 'V_AutoOfcversions',
      idName: 'ofcversion',
      properties: {
        "ofcversion": {
          name: 'ofcversion',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
