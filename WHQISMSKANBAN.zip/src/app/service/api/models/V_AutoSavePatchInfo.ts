/* tslint:disable */

declare var Object: any;
export interface V_AutoSavePatchInfoInterface {
  "computername"?: string;
  "setvalue"?: string;
  "actualvalue"?: string;
  "createdate"?: Date;
  "updatedate"?: Date;
  "installuser"?: string;
  "installdate"?: Date;
  "Sitename"?: string;
}

export class V_AutoSavePatchInfo implements V_AutoSavePatchInfoInterface {
  "computername": string;
  "setvalue": string;
  "actualvalue": string;
  "createdate": Date;
  "updatedate": Date;
  "installuser": string;
  "installdate": Date;
  "Sitename": string;
  constructor(data?: V_AutoSavePatchInfoInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoSavePatchInfo`.
   */
  public static getModelName() {
    return "V_AutoSavePatchInfo";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoSavePatchInfo for dynamic purposes.
  **/
  public static factory(data: V_AutoSavePatchInfoInterface): V_AutoSavePatchInfo{
    return new V_AutoSavePatchInfo(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoSavePatchInfo',
      plural: 'V_AutoSavePatchInfos',
      path: 'V_AutoSavePatchInfos',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "setvalue": {
          name: 'setvalue',
          type: 'string'
        },
        "actualvalue": {
          name: 'actualvalue',
          type: 'string'
        },
        "createdate": {
          name: 'createdate',
          type: 'Date'
        },
        "updatedate": {
          name: 'updatedate',
          type: 'Date'
        },
        "installuser": {
          name: 'installuser',
          type: 'string'
        },
        "installdate": {
          name: 'installdate',
          type: 'Date'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
