/* tslint:disable */

declare var Object: any;
export interface ACVUserAuthorityInterface {
  "EmployeeID"?: string;
  "UserName"?: string;
  "UserGroup"?: string;
  "Authority"?: string;
}

export class ACVUserAuthority implements ACVUserAuthorityInterface {
  "EmployeeID": string;
  "UserName": string;
  "UserGroup": string;
  "Authority": string;
  constructor(data?: ACVUserAuthorityInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `ACVUserAuthority`.
   */
  public static getModelName() {
    return "ACVUserAuthority";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of ACVUserAuthority for dynamic purposes.
  **/
  public static factory(data: ACVUserAuthorityInterface): ACVUserAuthority{
    return new ACVUserAuthority(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'ACVUserAuthority',
      plural: 'ACVUserAuthorities',
      path: 'ACVUserAuthorities',
      idName: 'EmployeeID',
      properties: {
        "EmployeeID": {
          name: 'EmployeeID',
          type: 'string'
        },
        "UserName": {
          name: 'UserName',
          type: 'string'
        },
        "UserGroup": {
          name: 'UserGroup',
          type: 'string'
        },
        "Authority": {
          name: 'Authority',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
