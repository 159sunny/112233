/* tslint:disable */

declare var Object: any;
export interface AutoWINversionInterface {
  "WINname"?: string;
  "WINnameKey"?: string;
}

export class AutoWINversion implements AutoWINversionInterface {
  "WINname": string;
  "WINnameKey": string;
  constructor(data?: AutoWINversionInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `AutoWINversion`.
   */
  public static getModelName() {
    return "AutoWINversion";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of AutoWINversion for dynamic purposes.
  **/
  public static factory(data: AutoWINversionInterface): AutoWINversion{
    return new AutoWINversion(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'AutoWINversion',
      plural: 'AutoWINversions',
      path: 'AutoWINversions',
      idName: 'WINname',
      properties: {
        "WINname": {
          name: 'WINname',
          type: 'string'
        },
        "WINnameKey": {
          name: 'WINnameKey',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
