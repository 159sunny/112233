/* tslint:disable */

declare var Object: any;
export interface V_specificAppInterface {
  "computername"?: string;
  "APPnameKey"?: string;
  "Sitename"?: string;
}

export class V_specificApp implements V_specificAppInterface {
  "computername": string;
  "APPnameKey": string;
  "Sitename": string;
  constructor(data?: V_specificAppInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_specificApp`.
   */
  public static getModelName() {
    return "V_specificApp";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_specificApp for dynamic purposes.
  **/
  public static factory(data: V_specificAppInterface): V_specificApp{
    return new V_specificApp(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_specificApp',
      plural: 'V_specificApps',
      path: 'V_specificApps',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "APPnameKey": {
          name: 'APPnameKey',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
