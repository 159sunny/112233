/* tslint:disable */

declare var Object: any;
export interface V_admintotaldaybeforeInterface {
  "computername"?: string;
  "admintotal"?: string;
  "Sitename"?: string;
}

export class V_admintotaldaybefore implements V_admintotaldaybeforeInterface {
  "computername": string;
  "admintotal": string;
  "Sitename": string;
  constructor(data?: V_admintotaldaybeforeInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_admintotaldaybefore`.
   */
  public static getModelName() {
    return "V_admintotaldaybefore";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_admintotaldaybefore for dynamic purposes.
  **/
  public static factory(data: V_admintotaldaybeforeInterface): V_admintotaldaybefore{
    return new V_admintotaldaybefore(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_admintotaldaybefore',
      plural: 'V_admintotaldaybefores',
      path: 'V_admintotaldaybefores',
      idName: 'computername',
      properties: {
        "computername": {
          name: 'computername',
          type: 'string'
        },
        "admintotal": {
          name: 'admintotal',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
