import { Provider } from '@angular/core';


export class SessionstorageService {
  // public sessionStorage: any;

  constructor() {

   }

}
