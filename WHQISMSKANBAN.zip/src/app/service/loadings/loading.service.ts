import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {

  public patchisloding: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public localisloding: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public adminisloding: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public adminchangeisloading: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public officescanIsloading: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public servertotalIsloading: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public eosIsloading: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public winVIsloading: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  public AppIsloding: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);
  constructor() { }
}
