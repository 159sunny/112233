import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigureAsset } from './configloadpath';

@Injectable({
  providedIn: 'root'
})
export class ConfigloadService {
      // http請求
      private configure: any;
      constructor( private http: HttpClient) {
        this.configure = {};
      }
      // 批量導入configure檔

      public loadConfigure(assets: ConfigureAsset[]): Promise<boolean> {
        let assetsCount = 0;

        return new Promise<boolean>((resolve, reject) => {
          assets.forEach(async (asset) => {
            this.configure[asset.type] = await this.http.get<any>(asset.path)
              .toPromise();
            assetsCount++;

            if (assetsCount === assets.length) {
              resolve(true);
            }
          });
        });
      }

      // 取到所有的設定檔
      public getAllConfigure(): any {
        return this.configure;
      }

      // 取得特定種類的設定檔
      public getSpecificConfigure(type: string): any {
      return this.configure[type];
      }

      // 取得設定檔的種類
      public getConfigureType(): string[] {
      const typeList = [];
      for (const type in this.configure) {
        if (this.configure.hasOwnProperty(type)) {
          typeList.push(type);
        }
      }

      return typeList;
      }

      public setConfigure(type: string, content: any): void {
      this.configure[type] = content;
      }

}
