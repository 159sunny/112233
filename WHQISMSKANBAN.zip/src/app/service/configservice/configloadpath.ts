export class ConfigureAsset {
  path: string;
  type: string;
}
