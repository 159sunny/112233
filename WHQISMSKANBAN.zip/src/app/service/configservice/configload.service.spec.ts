import { TestBed } from '@angular/core/testing';

import { ConfigloadService } from './configload.service';

describe('ConfigloadService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConfigloadService = TestBed.get(ConfigloadService);
    expect(service).toBeTruthy();
  });
});
