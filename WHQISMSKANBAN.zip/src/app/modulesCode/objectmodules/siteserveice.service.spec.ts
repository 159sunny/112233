import { TestBed } from '@angular/core/testing';

import { SiteserveiceService } from './siteserveice.service';

describe('SiteserveiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SiteserveiceService = TestBed.get(SiteserveiceService);
    expect(service).toBeTruthy();
  });
});
