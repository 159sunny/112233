import { Injectable, OnDestroy } from '@angular/core';
import { UserIFOService } from '../objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';
import { ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SiteserveiceService implements OnDestroy {
  public sitedatalist: ReplaySubject<any> = new ReplaySubject<any>(1);
  constructor(
    private userIFOService: UserIFOService
  ) { }

  private subscription: Subscription;

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }

  public Sitelist(): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
    this.userIFOService.UserSite.asObservable()
    .subscribe(async site => {
        if (site === 'All') {
         const sitedatalist = await this.sitelist();
         sitedatalist.forEach(data => {
          sitedatalist.push(data);
         });
        } else {
          this.sitedatalist[0] = site;
        }
      });
    resolve(this.sitedatalist);
     });
  }

  public sitelist(): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
        let sitelist: string[] = [];
        this.userIFOService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
          });
        resolve(sitelist);
        });
   }


}
