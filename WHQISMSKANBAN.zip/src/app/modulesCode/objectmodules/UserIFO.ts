import { Injectable } from '@angular/core';


@Injectable()
export class UserIFO {
  // user InFO object
  private static UserId: string;
  private static UserName: string;
  private static UserGroup: string;
  private static UserSite: string;
  private static Userpower: string;

  public static setUserId(UserId: string = ''): void {
     UserIFO.UserId = UserId;
  }
  public static getUserId() {
    return UserIFO.UserId;
  }

  public static setUserName(UserName: string = ''): void {
    UserIFO.UserName = UserName;
  }
  public static getUserName() {
    return UserIFO.UserName;
  }

  public static setUserGroup(UserGroup: string = ''): void {
    UserIFO.UserGroup = UserGroup;
  }
  public static getUserGroup() {
    return UserIFO.UserGroup;
  }
  public static setUserSite(UserSite: string = ''): void {
    UserIFO.UserSite = UserSite;
  }
  public  static getUserSite() {
   return UserIFO.UserSite;
  }
  public static setUserpower(Userpower: string = ''): void {
    UserIFO.Userpower = Userpower;
  }
  public static getUserpower() {
    return UserIFO.Userpower;
  }
}

