import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserIFOService {

  public UserId: ReplaySubject<string> = new ReplaySubject<string>(1);
  public UserName: ReplaySubject<string> = new ReplaySubject<string>(1);
  public UserGroup: ReplaySubject<string> = new ReplaySubject<string>(1);
  public UserSite: ReplaySubject<string> = new ReplaySubject<string>(1);
  public Userpower: ReplaySubject<string> = new ReplaySubject<string>(1);

  constructor() { }

}

// export class userIFOs {
//   constructor(UserId: string, UserName: string, UserGroup: string, UserSite: string, Userpower: string) {

//   }
// }
