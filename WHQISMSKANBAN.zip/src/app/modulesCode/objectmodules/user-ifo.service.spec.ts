import { TestBed } from '@angular/core/testing';

import { UserIFOService } from './user-ifo.service';

describe('UserIFOService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserIFOService = TestBed.get(UserIFOService);
    expect(service).toBeTruthy();
  });
});
