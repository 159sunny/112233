import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfficescanComponent } from './officescan.component';

describe('OfficescanComponent', () => {
  let component: OfficescanComponent;
  let fixture: ComponentFixture<OfficescanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficescanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficescanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
