import { Component, OnInit,  OnDestroy } from '@angular/core';
import { V_AutoOfcversionApi, V_AutoCompareComputerInfoApi, V_ComputernameApi} from '../../../service/api/index';
import { Subscription } from 'rxjs';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { LoadingService } from 'src/app/service/loadings/loading.service';
import { max } from 'rxjs/operators';

@Component({
  selector: 'app-officescan',
  templateUrl: './officescan.component.html',
  styleUrls: ['./officescan.component.scss']
})
export class OfficescanComponent implements OnInit,  OnDestroy {
  center: any = ['40%', '65%'];
  radius: any = [0, '45%'];

  showtitles: any = [];
  datashows: any = [];
  Agent: any;
  AbAgent: any;
  AbAgentTotal: any;
  AgentTotal: any;
  ServiceTotal: any;
  AbServiceTotal: any;
  Service: any;
  AbService: any;
  dataBL: any;
  offsion: any;
  height = 'offscan';
  private subscription: Subscription;

  constructor(
    private ofcversion: V_AutoOfcversionApi,
    private ofcversiontotal: V_AutoCompareComputerInfoApi,
    private userInfoService: UserIFOService,
    private computername: V_ComputernameApi,
    private loading: LoadingService
  ) { }

 async ngOnInit() {
  await this.ofcversiontotals();
  }

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }


  // ofc 數量查詢
  public ofcversiontotals(): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
      this.userInfoService.UserSite
      .asObservable()
      .subscribe(async siteSelect => {
          this.loading.officescanIsloading.next(false);
          this.showtitles = [];
          this.datashows = [];
          this.dataBL = [];
          let title = [];
          let totallist = [];
          let totalBL = [];
          await this.query(siteSelect)[0];
          await this.query(siteSelect)[1];
          const version = await this.ofcversionQuery();
          const resultlist = [];
          let result = 0;
          let allresult = 0;

          if (siteSelect === 'All') {
              const site = await this.sitelist();
              // console.log(site);
              // tslint:disable-next-line: prefer-for-of
              for (let i = 0; i < version.length; i++) {
                result = 0;
                if  (version[i] !== '') {
                    // tslint:disable-next-line: prefer-for-of
                    // for (let j = 0; j < site.length; j++) {
                    const total = await this.ofcversiontotal.count(
                        {and: [
                          {ofcversion: version[i]},
                          {Sitename: {inq: site}}
                        ]}
                      ).toPromise();
                    result += await total.count;
                    if (result > 0) {
                        resultlist.push(result);
                      } else {
                        resultlist.push(0);
                      }
                    }
                }
                console.log("TTTTTTTTTTTTTTTTT");
              const maxtotal = Math.max.apply(Math, resultlist);
              console.log(maxtotal);
              const maxindexof = resultlist.indexOf(maxtotal);
              console.log("測試log"+maxindexof);
              let normalversion1 = version[maxindexof];
              const normalversion2 = (parseInt(normalversion1) - 2).toString();
              const normalversion3 = (parseInt(normalversion1) + 2).toString();
              const maxindexof2 = version.indexOf(normalversion2);
              const maxindexof3 = version.indexOf(normalversion3);
              // this.offsion="'"+normalversion1+"'";
              // if(normalversion2!=undefined){
              //   this.offsion +=","+"'"+normalversion2+"'";
              // }
              // if(normalversion3!=undefined){
              //   this.offsion +=","+"'"+ normalversion3;
              // }
              // this.offsion += "'";

              this.offsion = normalversion1;
              if (normalversion2!= undefined) {
                  this.offsion +=","+normalversion2;
                }
              if (normalversion3!=undefined) {
                  this.offsion +=","+normalversion3;
                }
              let maxindexoftotal2 = resultlist[maxindexof2];
              let maxindexoftotal3 = resultlist[maxindexof3];
              if (maxindexof2 === -1) {
                maxindexoftotal2 = 0;
              }
              if (maxindexof3 === -1) {
                maxindexoftotal3 = 0;
              }
              let IusseVersion = 0;
              for (let i = 0; i < resultlist.length; i++) {
                if (i !== maxindexof && i !== maxindexof2 && i !== maxindexof3) {
                    IusseVersion += resultlist[i];
                }

              }
              const total = await this.ofcversiontotal.count(
                  {and: [
                    {ofcversion: ''},
                    {Sitename: siteSelect}
                  ]}
                ).toPromise();

              allresult += await total.count;
              // resultlist.push({value: allresult, name: version[2]});
              const IusseTotal =   IusseVersion + allresult;
              const NormalTotal = maxtotal + maxindexoftotal2 + maxindexoftotal3;
              // console.log(Math.max.apply(Math, resultlist) + maxindexoftotal2);
              totallist = [this.AgentTotal, this.AbAgentTotal, this.ServiceTotal, this.AbServiceTotal, NormalTotal, IusseTotal];
              const normalBL = parseInt(((NormalTotal / (NormalTotal + IusseTotal)) * 100).toFixed(0));
              const IssueBL = parseInt((( IusseTotal / (NormalTotal + IusseTotal)) * 100).toFixed(0));
              totalBL = [this.Agent, this.AbAgent, this.Service, this.AbService, normalBL, IssueBL];
              allresult = 0;

            } else {
                // tslint:disable-next-line: prefer-for-of
                for (let i = 0; i < version.length; i++) {
                  if  (version[i] !== '') {
                      result = 0;
                      const total = await this.ofcversiontotal.count(
                        {and: [
                          {ofcversion: version[i]},
                          {Sitename: siteSelect}
                        ]}
                      ).toPromise();
                      result += await total.count;
                      if (result > 0) {
                        resultlist.push(result);
                      } else {
                        resultlist.push(0);
                      }
                    }
                }
                console.log("TTTTTTTTTTTTTTTTT");
                const maxtotal = Math.max.apply(Math, resultlist);
                console.log(maxtotal);
                const maxindexof = resultlist.indexOf(maxtotal);
                console.log("測試log"+maxindexof);
                let normalversion1 = version[maxindexof];
                const normalversion2 = (parseInt(normalversion1) - 2).toString();
                const normalversion3 = (parseInt(normalversion1) + 2).toString();

                // this.offsion="'"+normalversion1+"'";
                // if(normalversion2!=undefined){
                //   this.offsion +=","+"'"+normalversion2+"'";
                // }
                // if(normalversion3!=undefined){
                //   this.offsion +=","+"'"+ normalversion3;
                // }
                // this.offsion += "'";

                this.offsion=normalversion1;
                if(normalversion2!=undefined){
                  this.offsion +=","+normalversion2;
                }
                if(normalversion3!=undefined){
                  this.offsion +=","+normalversion3;
                }
                // this.offsion += "'";
                const maxindexof2 = version.indexOf(normalversion2);
                const maxindexof3 = version.indexOf(normalversion3);
                let maxindexoftotal2 = resultlist[maxindexof2];
                let maxindexoftotal3 = resultlist[maxindexof3];
                if (maxindexof2 === -1) {
                  maxindexoftotal2 = 0;
                }
                if (maxindexof3 === -1) {
                  maxindexoftotal3 = 0;
                }
                let IusseVersion = 0;
                for (let i = 0; i < resultlist.length; i++) {
                  if (i !== maxindexof && i !== maxindexof2 && i !== maxindexof3) {
                      IusseVersion += resultlist[i];
                  }

                }
                const total = await this.ofcversiontotal.count(
                    {and: [
                      {ofcversion: ''},
                      {Sitename: siteSelect}
                    ]}
                  ).toPromise();
                allresult += await total.count;
                const IusseTotal =   IusseVersion + allresult;
                const NormalTotal = maxtotal + maxindexoftotal2 + maxindexoftotal3;
                totallist = [this.AgentTotal, this.AbAgentTotal, this.ServiceTotal, this.AbServiceTotal, NormalTotal, IusseTotal];
                console.log("YYYYYYYYYY");
                console.log(this.AgentTotal);
                console.log(this.AbAgentTotal);
                console.log(this.ServiceTotal);
                console.log(this.AbServiceTotal);
                console.log(NormalTotal);
                console.log(IusseTotal);
                // console.log(Math.max.apply(Math, resultlist) + maxindexoftotal2);
                // totallist = [NormalTotal, IusseTotal];
                const normalBL = parseInt(((NormalTotal / (NormalTotal + IusseTotal)) * 100).toFixed(0));
                const IssueBL = parseInt((( IusseTotal / (NormalTotal + IusseTotal)) * 100).toFixed(0));
                totalBL = [this.Agent, this.AbAgent, this.Service, this.AbService, normalBL, IssueBL];

                allresult = 0;
                }
          title = ['AgentRatio', 'NonAgentRatio', 'ServiceNormal', 'ServiceAbnormal', 'PatternNormal', 'PatternAbnormal'];
          this.showtitles = title;
          this.datashows = totallist;
          this.dataBL = totalBL;
          // console.log(title);
          // console.log(totallist);
          // console.log(totalBL);
          this.loading.officescanIsloading.next(true);
      });
      resolve();
    });
  }


    // ofc 版本查詢
    public  ofcversionQuery(): Promise<any>  {
      return new Promise<any> (async (resolve, reject) => {
        const ofcversionlist: string[] = [];
        const ofcversion = await this.ofcversion.find().toPromise();
        ofcversion.forEach(data => {
          ofcversionlist.push(Object.values(data).toString());
        });
        resolve(ofcversionlist);
      });
    }

    private sitelist(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist: string[] = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }



  public async query(siteSelect: string) {
        let AgentTotal = 0;
        let ServiceTotal = 0;
        let Total = 0;
        if (siteSelect === 'All') {
          const site = await this.sitelist();
          // tslint:disable-next-line: prefer-for-of
          // for (let i = 0; i < site.length; i++) {
          const Agentresutl = await this.offcanAgent(site);
          const Serviceresutl = await this.offcanService(site);
          AgentTotal += Agentresutl[0];
          ServiceTotal += Serviceresutl[0];
          Total += Agentresutl[1];
          // }
        } else {
          const resutl1 = await this.offcanAgent([siteSelect]);
          const resutl2 = await this.offcanService([siteSelect]);
          AgentTotal += resutl1[0];
          console.log("ppppppp");
          console.log(resutl1[0]);
          ServiceTotal += resutl2[0];
          console.log("pppppppttttt");
          console.log(resutl2[0]);
          Total = resutl1[1];
        }
        const Angetbl = ((AgentTotal / Total) * 100).toFixed(0);
        const Servicebl = ((ServiceTotal / Total) * 100).toFixed(0);
        this.Agent = Angetbl;
        this.Service = Servicebl;
        this.AbAgent = 100 - parseInt(Angetbl);
        this.AbService = 100 - parseInt(Servicebl);
        this.AgentTotal = AgentTotal;
        this.AbAgentTotal = Total - AgentTotal;
        this.ServiceTotal = ServiceTotal;
        this.AbServiceTotal = Total - ServiceTotal;
        // console.log(this.Agent);
  }

  // Offcan Agent查询
  public async offcanAgent(site: string[] ) {
      const offcanAgentTotal = await this.ofcversiontotal.count({
        and: [
          { Sitename: {inq: site} },
          {
          or: [
            { ofcntrtscan: '4RUNNING' },
            { ofctmlisten: '4RUNNING' }
          ]
          }
        ]
      }).toPromise();
      const Total = offcanAgentTotal.count;
      const OffcanTotal = await this.ofcversiontotal.count(
        {Sitename: {inq: site}}
      ).toPromise();
      const offcanTotal = OffcanTotal.count;
      const datalist = [Total, offcanTotal];
      return datalist;

  }


  // Offcan Service查询
  public async offcanService(site: string[] ) {
    const offcanAgentTotal = await this.ofcversiontotal.count({
      and: [
        { Sitename: {inq: site} },
        { ofcntrtscan: '4RUNNING' },
        { ofctmlisten: '4RUNNING' }
      ]
    }).toPromise();
    const Total = offcanAgentTotal.count;
    return [Total];

}

// Computername查询
public async Computername( site: string) {
  const namelist = [];
  const namedata = this.computername.find({where: {Sitename: site}}).toPromise();
  (await namedata).forEach(data => {
      namelist.push(Object.values(data)[0]);
  });
  // console.log(site);
  // console.log(namelist);
  return namelist;
}

}
