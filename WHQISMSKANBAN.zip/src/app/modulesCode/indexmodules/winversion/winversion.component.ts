import { Component, OnInit, OnDestroy } from '@angular/core';
import { V_AutoWINversionApi, AutoWINversionApi, V_AutoCompareComputerInfoApi} from '../../../service/api/index';
import { Subscription } from 'rxjs';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { LoadingService } from 'src/app/service/loadings/loading.service';


@Component({
  selector: 'app-winversion',
  templateUrl: './winversion.component.html',
  styleUrls: ['./winversion.component.scss']
})
export class WinversionComponent implements OnInit, OnDestroy {
  center: any = ['40%', '60%'];
  radius: any = [0, '60%'];
  height = 'windversion';
  // showtitles: any = ['Wind2003', 'Wind2008', 'Wind2010', 'Wind2013', 'Wind2012R'];
  // datashows: any = [
  //   {value: 335, name: 'Wind2003'},
  //   {value: 679, name: 'Wind2008'},
  //   {value: 1548, name: 'Wind2010'},
  //   {value: 1548, name: 'Wind2013'},
  //   {value: 1548, name: 'Wind2012R'}
  // ];
  showtitles: any;
  datashows: any;
  dataBL: any;
  // 页数
  nowpages: any = 1;
  totalpages: any = 1;
  pagesremainder: any = 0;

  keylists: any;
  alltotal: any;
  totalarry: any;
  private subscription: Subscription;
  constructor(
    private winnamekey: V_AutoWINversionApi,
    private winversionlist: AutoWINversionApi,
    private wintotal: V_AutoCompareComputerInfoApi,
    private userInfoService: UserIFOService,
    private loading: LoadingService
  ) { }


  async ngOnInit() {
    await this.queryWinTotalInfo();
    }

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }



  private queryWinTotalInfo(): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.userInfoService.UserSite
      .asObservable()
      .subscribe(async site => {
        this.loading.winVIsloading.next(false);
        // subscription = await site;
        const dataifolist = [];
        const title = [];
        const BL = [];
        let Alltotal = 0;
        const keylist = await this.winNameKey();
        this.keylists =  keylist.reverse();
        for (let i = 0; i < keylist.length; i++) {
          const versionlist = await this.winVersionList(keylist[i]);
          // console.log(versionlist);
          const total = await this.WINtotal(versionlist, site);
          dataifolist.push(total);
        }
        for(let i = 0; i < dataifolist.length; i++) {
          Alltotal +=  dataifolist[i];
        }
        this.totalarry = dataifolist;
        this.alltotal = Alltotal;
        // tslint:disable-next-line: prefer-for-of
        if ( keylist.length < 4 ) {
          this.showtitles = keylist;
          this.datashows = dataifolist;
          for(let i = 0; i < this.datashows.length; i++) {
           // tslint:disable-next-line: radix
           BL.push(parseInt(((this.datashows[i] / Alltotal) * 100).toFixed(0)));
          }
          this.dataBL = BL;
        } else {
          if (keylist.length % 4 === 0) {
            this.totalpages = keylist.length / 4;
          } else {
            this.totalpages = keylist.length / 4 + 1;
            // tslint:disable-next-line: radix
            this.totalpages = parseInt(this.totalpages);
            this.pagesremainder = keylist.length % 4;
          }

          this.pagping(this.keylists, this.totalarry, this.alltotal);
        }
        this.loading.winVIsloading.next(true);
        });
      resolve();
    });
  }


  public pagping(keylist: any[], totallist: any[], Alltotal: any): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
      this.datashows = [];
      this.showtitles = [];
      this.dataBL = [];
      const dataifolist = [];
      const title = [];
      const BL = [];
      if (this.nowpages < this.totalpages) {
        for (let i = this.nowpages * 4 - 4; i < (this.nowpages * 4); i++) {
          title.push(keylist[i]);
          dataifolist.push(totallist[i]);
        }
      } else {
        if (this.pagesremainder === 0) {
          for (let i = this.nowpages * 4 - 4; i < (this.nowpages * 4); i++) {
            title.push(keylist[i]);
            dataifolist.push(totallist[i]);
          }
        } else {
          for (let i = this.nowpages * 4 - 4; i < ((this.nowpages * 4) - 4) + this.pagesremainder; i++) {
            title.push(keylist[i]);
            dataifolist.push(totallist[i]);
          }
        }
      }
      for(let i = 0; i < dataifolist.length; i++) {
       // tslint:disable-next-line: radix
       BL.push(parseInt(((dataifolist[i] / Alltotal) * 100).toFixed(0)));
      }
      this.dataBL = BL;
      this.datashows = dataifolist;
      this.showtitles = title;
      this.loading.winVIsloading.next(true);
    });
  }

  //遍歷win版本
  public winNameKey(): Promise<any> {
    return new Promise<any>(async ( resolve , reject) => {
      const WinKeylist = [];
      const WinKey = await this.winnamekey.find().toPromise();
      WinKey.forEach(data => {
        console.log("123"+Object.values(data).toString());
        WinKeylist.push(Object.values(data).toString());

      });
      resolve(WinKeylist);
    });
  }

  public winVersionList(WinKey: string): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
        const versionlist = [];
        const version = await this.winversionlist.find({where: {WINnameKey: WinKey}}).toPromise();
        version.forEach(data => {
          versionlist.push(Object.values(data)[0].toString());
        });
        resolve(versionlist);
    });
  }

  public WINtotal(version: string, Siet: string): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
      let total = 0;
      if (Siet === 'All') {
        const site = await this.sitelist();
        const versionquery = await this.wintotal.count(
                {and: [
                  {osversion: {inq: version}},
                  {Sitename: {inq: site}}
                ]}
              ).toPromise();
        total = versionquery.count;
      } else {
          const versionquery = await this.wintotal.count(
            {and: [
              {osversion: {inq: version}},
              {Sitename: Siet}
            ]}
          ).toPromise();
          total = versionquery.count;
      }
      resolve(total);
    });
  }



  private sitelist(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist: string[] = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }

  public async uppages() {
      this.nowpages --;
      if (this.nowpages < 1) {
        this.nowpages = 1;
        return;
      }
      this.pagping(this.keylists, this.totalarry, this.alltotal);

    }

  public async nextpages() {
        this.nowpages ++;
        if (this.nowpages > this.totalpages) {
          this.nowpages = this.totalpages;
          return;
        }
        this.pagping(this.keylists, this.totalarry, this.alltotal);
    }


}
