import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WinversionComponent } from './winversion.component';

describe('WinversionComponent', () => {
  let component: WinversionComponent;
  let fixture: ComponentFixture<WinversionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WinversionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WinversionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
