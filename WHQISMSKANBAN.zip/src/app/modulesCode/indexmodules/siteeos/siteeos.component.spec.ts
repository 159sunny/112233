import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteeosComponent } from './siteeos.component';

describe('SiteeosComponent', () => {
  let component: SiteeosComponent;
  let fixture: ComponentFixture<SiteeosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteeosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteeosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
