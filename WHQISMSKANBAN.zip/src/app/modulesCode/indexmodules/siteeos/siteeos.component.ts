import { Component, OnInit, OnDestroy } from '@angular/core';
import { V_AutoCompareComputerInfoApi } from '../../../service/api/index';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { AutoEOSversionApi} from '../../../service/api/index';
import { Subscription } from 'rxjs';

import { LoadingService } from 'src/app/service/loadings/loading.service';


@Component({
  selector: 'app-siteeos',
  templateUrl: './siteeos.component.html',
  styleUrls: ['./siteeos.component.scss']
})
export class SiteeosComponent implements OnInit, OnDestroy {
  radius: any = ['95%', '80%'];
  center: any = [ '50%' , '50%'];
  private subscription: Subscription;
  // apprate1: any = 0;
  // 实际EOS
  actualresult1: any = 0;
  actualresult2: any = 0;
  actualresult3: any = 0;
  actualresult4: any = 0;
  actualresult5: any = 0;
  actualresult6: any = 0;
  actualresult7: any = 0;
  actualresult8: any = 0;
  // 所有的版本
  total1: any = 100;
  total2: any = 100;
  total3: any = 100;
  total4: any = 100;
  total5: any = 100;
  total6: any = 100;
  total7: any = 100;
  total8: any = 100;

  totals1: any = '0';
  totals2: any = '0';
  totals3: any = '0';
  totals4: any = '0';
  totals5: any = '0';
  totals6: any = '0';
  totals7: any = '0';
  totals8: any = '0';
  // 标题
  title1: any;
  title2: any;
  title3: any;
  title4: any;
  title5: any;
  title6: any;
  title7: any;
  title8: any = '';
  eosver: string[] = [];

  // 占有率
  apprate1: any ;
  apprate2: any ;
  apprate3: any ;
  apprate4: any ;
  apprate5: any ;



  actualresult: any;
  total: any;
  title: any;
  totals: any;
  eosversion: any;
  sitelist: string[];

  totaloff = true;
  // 页数
  nowpages: any = 1;
  totalpages: any = 1;
  pagesremainder: any = 0;
  offshow = false;
  Alloff = false;
  lengths: any;
  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }




  constructor(
    private eos: V_AutoCompareComputerInfoApi,
    private userIFOService: UserIFOService,
    private EOSversion: AutoEOSversionApi,
    private loadigservice: LoadingService
  ) { }

 async ngOnInit() {
   await  this.EOSquery();
  //  await this.uppages();
  //  await this.nextpages();
  }


  /**
   * EOSquery
   */
  public EOSquery(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      this.userIFOService.UserSite.asObservable()
      .subscribe(async userSite => {
      this.loadigservice.eosIsloading.next(false);
      this.userIFOService.Userpower.asObservable()
      .subscribe(async userpower => {
         this.actualresult = [[0], [0], [0], [0]];
         this.title = ['NA', 'NA', 'NA', 'NA'];
         this.total = [1, 1, 1, 1];
         this.totals = [0, 0, 0, 0];
        //  this.sitelist = [];
        // tslint:disable-next-line: one-variable-per-declaration
         this.eosversion =  await this.queryEOSversion();
         console.log("我是最前面的查詢版本" + this.eosversion);
        // if ( userpower.length > 5) {
        this.sitelist = [];

         if (userSite === 'All') {
            this.Alloff = true;
            this.offshow = true;
            this.sitelist = await userpower.split(',');
            console.log("返回site的長度"+ this.sitelist.length);
            // const sitearry = await userpower.split(',');
            // sitearry.unshift(userSite);
            // console.log( "新增All" + sitearry.length);
          } else {
            this.Alloff = false;
            this.offshow = false;
            this.nowpages = 1;
            this.totalpages = 1;
            this.pagesremainder = 0;
            this.sitelist.push(userSite);
            // this.sitelist.length = this.sitelist.length.toString() + 1;
            console.log(this.sitelist.length);
          }
          //  console.log(this.sitelist);
          // console.log(sitelist.lengths);
         if (this.sitelist.length < 4) { //總數只有3個site,在一頁上就能夠顯示完
              for (let i = 0; i < this.sitelist.length; i++) {
                // for(let j = 0; j < eosversion.length; j++){
                  this.title[i] = await this.sitelist[i];
                  const result = await this.chaxun(this.sitelist[i], this.eosversion);
                  // console.log(sitelist[i]);
                  // console.log(result);
                  this.actualresult[i] = result;
                  if (this.actualresult[i][1] === 0) {
                    this.total[i]  = 1;
                  } else {
                    this.total[i] = await this.actualresult[i][1] - await this.actualresult[i][0];
                  }
                  this.totals[i] = this.actualresult[i][1];

                // }
              }

          } else {

            // const lengths = await this.sitelist.length / 4;
            // console.log("site為All,當前的長度為"+ lengths);
            // this.totalpages = await parseInt(lengths.toString());
            // if (this.sitelist.length % 4 > 0) {
            //   await this.totalpages ++;
            //   this.pagesremainder = await this.sitelist.length % 4;
            // }
            // await this.paging();

            if ( this.sitelist.length % 4 === 0 ) {
              const lengths = await this.sitelist.length / 4; //5
              console.log("7777" + this.sitelist.length / 4);
              // tslint:disable-next-line: radix
              this.totalpages = await parseInt(lengths.toString());
            } else {
              this.totalpages = parseInt ( this.sitelist.length.toString()) + 1;
              console.log("888 "+ this.totalpages);
               this.pagesremainder = await this.sitelist.length % 4;
            }
            console.log("現在獲取" + this.lengths);
            await this.paging();
          }

          // else {
          //   // 分页功能部分
          //  const lengths = await this.sitelist.length  / 4;
          //  console.log("site的長度" + lengths.toString());
          //  // tslint:disable-next-line: radix
          //  this.totalpages = await parseInt(lengths.toString());
          //  if (this.sitelist.length % 4 > 0) {
          //    await this.totalpages ++;
          //    this.pagesremainder = await this.sitelist.length % 4;
          //  }
          //  await this.paging();
          // //  console.log(this.totalpages);
          // }
        // console.log(this.actualresult);
        // 实际EOS

         this.actualresult2 =  this.actualresult[0][0];
         this.actualresult3 =  this.actualresult[1][0];
         this.actualresult4 =  this.actualresult[2][0];
         this.actualresult5 =  this.actualresult[3][0];

        // 所有的版本
        //  this.total1 = 'All';
         this.total2 =  this.total[0];
         this.total3 =  this.total[1];
         this.total4 =  this.total[2];
         this.total5 =  this.total[3];

         this.apprate2 = (( this.actualresult[0][0] / this.actualresult[0][1]) * 100).toFixed(0);
         this.apprate3 = (( this.actualresult[1][0] / this.actualresult[1][1]) * 100).toFixed(0);
         this.apprate4 = (( this.actualresult[2][0]  / this.actualresult[2][1]) * 100).toFixed(0);
         this.apprate5 = (( this.actualresult[3][0] / this.actualresult[3][1]) * 100).toFixed(0);
         if (this.apprate2 === 'NaN') {
          this.apprate2 = 0;
         }
         if (this.apprate3 === 'NaN') {
          this.apprate3 = 0;
         }
         if (this.apprate4 === 'NaN') {
          this.apprate4 = 0;
         }
         if (this.apprate5 === 'NaN') {
          this.apprate5 = 0;
         }
         this.totals2 = this.totals[0].toString();
         this.totals3 = this.totals[1].toString();
         this.totals4 = this.totals[2].toString();
         this.totals5 = this.totals[3].toString();

         // 标题
         this.title1 = 'All';
         this.title2 =  this.title[0];
         this.title3 =  this.title[1];
         this.title4 =  this.title[2];
         this.title5 =  this.title[3];
         if (this.totaloff) {
          await this.totalBL( await userpower.split(','), this.eosversion);
          this.totaloff = false;
         }

         this.loadigservice.eosIsloading.next(true);
         resolve();
      }, error => {
        reject(error);
      });
    });
    });
  }



  public async totalBL(site: any, Osversion: any): Promise<any[]> {//求總的site EOS數量
    return new Promise<any[]>(async (resolve, reject) => {
        this.loadigservice.eosIsloading.next(false);
        let actualresult = 0;
        let total = 0;
        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < site.length; i++) {
            console.log("總數");
            const result = await this.chaxun(site[i], Osversion);
            console.log(result);
            // console.log(sitelist[i]);
            // console.log(result);
            actualresult += result[0];
            total += result[1];
        }
        this.actualresult1 = actualresult; // EOS實際總的
        this.totals1 = total.toString(); // EOS總的
        this.total1 = total - actualresult; //  圓形比例
        this.apprate1 = ((actualresult / total) * 100).toFixed(0); // 比率

        this.loadigservice.eosIsloading.next(true);
        resolve();
    });
  }

  public async chaxun( site: string, Osversion: any[]): Promise<any[]> {
    return new Promise<any[]>(async (resolve, reject) => {
      // EOS total
      let result = 0;
      // tslint:disable-next-line: prefer-for-of
      for (let j = 0; j < Osversion.length; j++) {
        const version: string = '%' +  Osversion[j] + '%';
        // console.log(version, site);
        const actualresult = await this.eos.count(
          {and: [
            {Sitename: site},
            {osversion: {like:  version}}
          ]
          }
        ).toPromise();
        result += actualresult.count;
        // console.log(actualresult);
      }
      // win版本 total
      const actualresulttotal = await this.eos.count(
          {Sitename: site}
      ).toPromise();
      const resulttotal = actualresulttotal.count;
      const data = [result, resulttotal];
      // console.log(site);
      // console.log(data);
      resolve(data);
  });
}

  public async queryEOSversion( ): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
      const eosversion = await this.EOSversion.find().toPromise();
      console.log("遍歷出來的eos版本" + eosversion);
      const version: string[] = [];
      eosversion.forEach(async data => {
        //  console.log(await Object.values(data).toString());
        console.log("2222222"+this.Alloff);
        version.push(await Object.values(data).toString());

      });
      resolve(version);
  });
  }
  // 分页查询功能
  public paging(): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {

      // if ((this.nowpages > 1 && this.totalpages > 1) || this.totalpages === 1) {
      //     this.Alloff = false;
      // }
      // if ( this.nowpages === 1 ) {
      //     this.Alloff = true;

      //     //  this.title[]=this.sitelist[];
      // }
      // 总页数：this.totalpages； 最后页的个数： this.pagesremainder
        // 当前页数与总页数的判断; 当前页数<总页数 的业务逻辑
      if (await this.nowpages < await this.totalpages) {
        if ( this.nowpages === 1 ) { //在第一頁的時候
          this.Alloff = true;
          const Queryfisrtindex = await this.nowpages * 4 - 4;
          const Queryendindex = await this.nowpages * 4;
          let j = 0;
          for (let i = Queryfisrtindex;  i < Queryendindex - 1; i++) {
            // this.Alloff = true;  //1
            this.title[j] = this.sitelist[i];
            const result = await this.chaxun(this.sitelist[i], this.eosversion);
            // console.log(sitelist[i]);
            // console.log(result);
            this.actualresult[j] = result;
            if (this.actualresult[j][1] === 0) {
              this.total[j] = 1;
            } else {
              this.total[j] = this.actualresult[j][1] - this.actualresult[j][0];
            }
            this.totals[j] = this.actualresult[j][1];
            j ++;
      }
        } else {
          this.Alloff = false;
          const Queryfisrtindex = await this.nowpages * 4 - 4 -1;
          const Queryendindex = await this.nowpages * 4;
          let j = 0;
          for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
            // this.Alloff = true;  //1
            this.title[j] = this.sitelist[i];
            const result = await this.chaxun(this.sitelist[i], this.eosversion);
            // console.log(sitelist[i]);
            // console.log(result);
            this.actualresult[j] = result;
            if (this.actualresult[j][1] === 0) {
              this.total[j] = 1;
            } else {
              this.total[j] = this.actualresult[j][1] - this.actualresult[j][0];
            }
            this.totals[j] = this.actualresult[j][1];
            j ++;
      }
        }
        // const Queryfisrtindex = await this.nowpages * 4 - 4;
        // const Queryendindex = await this.nowpages * 4;
        // let j = 0;
        // for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
        //       // this.Alloff = true;  //1
        //       this.title[j] = this.sitelist[i];
        //       const result = await this.chaxun(this.sitelist[i], this.eosversion);
        //       // console.log(sitelist[i]);
        //       // console.log(result);
        //       this.actualresult[j] = result;
        //       if (this.actualresult[j][1] === 0) {
        //         this.total[j] = 1;
        //       } else {
        //         this.total[j] = this.actualresult[j][1] - this.actualresult[j][0];
        //       }
        //       this.totals[j] = this.actualresult[j][1];
        //       j ++;
        // }
      } else {
        // 当前页数与总页数的判断; 当前页数=总页数 的业务逻辑
        // const Queryfisrtindex = await this.nowpages * 4 - 4;
            this.Alloff = false;
            let j = 0;
            // 是否有余数
            if (this.pagesremainder > 0) {
                const Queryfisrtindex = await this.nowpages * 4 - 4;
                // console.log('Queryfisrtindex');
                // console.log(Queryfisrtindex);
                for (let i = Queryfisrtindex;  i < Queryfisrtindex + this.pagesremainder; i++) {
                  this.title[j] = this.sitelist[i];
                  const result = await this.chaxun(this.sitelist[i], this.eosversion);
                  // console.log(sitelist[i]);
                  // console.log(result);
                  this.actualresult[j] = result;
                  if (this.actualresult[j][1] === 0) {
                    this.total[j] = 1;
                  } else {
                    this.total[j] = this.actualresult[j][1] - this.actualresult[j][0];
                  }
                  this.totals[j] = this.actualresult[j][1];
                  j ++;
              }
        } else {
              const Queryfisrtindex = await this.nowpages * 4 - 4;
              const Queryendindex = await this.nowpages * 4;
              for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
                this.title[j] = this.sitelist[i];
                const result = await this.chaxun(this.sitelist[i], this.eosversion);
                // console.log(sitelist[i]);
                // console.log(result);
                this.actualresult[j] = result;
                if (this.actualresult[j][1] === 0) {
                  this.total[j] = 1;
                } else {
                  this.total[j] = this.actualresult[j][1] - this.actualresult[j][0];
                }
                this.totals[j] = this.actualresult[j][1];
                j ++;
            }
        }
      }
      resolve();
    });
  }

 public async uppages() {
      console.log( "當前頁是" + this.nowpages);
      this.nowpages --;
      console.log( "當前頁減后是" + this.nowpages);
      if (this.nowpages < 1) {
        this.nowpages = 1;
        return;
      }
      this.EOSquery();
      // console.log('uppages');
      // console.log(this.actualresult);

  }

  public nextpages() {
        console.log( "當前頁下是" + this.nowpages);
        this.nowpages ++;
        if (this.nowpages > this.totalpages) {
          this.nowpages = this.totalpages;
          return;
        }
        this.EOSquery();
    }


  async onChartInit(e) {
      let check = 5;
      let site = e.currentTarget.previousElementSibling.innerHTML;
      window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+site);
    }
}
