import { Component, OnInit,  OnDestroy} from '@angular/core';
import { V_AutoSavePatchInfoApi, V_ComputernameApi  } from '../../../service/api/index';

import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';
import { LoadingService } from '../../../service/loadings/loading.service';

import { Router } from '@angular/router';
@Component({
  selector: 'app-patch',
  templateUrl: './patch.component.html',
  styleUrls: ['./patch.component.scss']
})
export class PatchComponent implements OnInit, OnDestroy {
  // center: any = ['40%', '17%'];
  // radius: any = [0, '25%'];
  // 名稱
  appname1: any = 'All';  //分別命名五個  一頁顯示5個
  appname2: any = 'NA';
  appname3: any = 'NA';
  appname4: any = 'NA';
  appname5: any = 'NA';
  // 数量
  GXtotal1: any = 0;
  GXtotal2: any = 0;
  GXtotal3: any = 0;
  GXtotal4: any = 0;
  GXtotal5: any = 0;


  QTtotal1: any = 1;
  QTtotal2: any = 1;
  QTtotal3: any = 1;
  QTtotal4: any = 1;
  QTtotal5: any = 1;
  // 总数
  apptotal1: any ;
  apptotal2: any ;
  apptotal3: any ;
  apptotal4: any ;
  apptotal5: any ;
  // 占有率
  apprate1: any ;
  apprate2: any ;
  apprate3: any ;
  apprate4: any ;
  apprate5: any ;


  Alloff = false;
  // 页数
  nowpages: any = 1;
  totalpages: any = 1;
  pagesremainder: any = 0;
  appkeynamelist: any;
  titlename: any;
  appinfolist: any;
  titlelist = ['NA', 'NA', 'NA' , 'NA' ];
  showtitles: any;
  datashows: any[];
  offshow = false;
  queryOne = true;




  private subscription: Subscription;

  constructor(
    private pacth: V_AutoSavePatchInfoApi,
    private userIFOService: UserIFOService,
    private computername: V_ComputernameApi,
    private loading: LoadingService,
    private router: Router
  ) {

  }

 async ngOnInit() {
    await this.patchQuery();
  }


  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }


  public  patchQuery(): Promise<any[]> {
    return new Promise<any[]>((resolve, reject) => {
        this.userIFOService.UserSite.asObservable()
        .subscribe(async userSite => {
          this.loading.patchisloding.next(false);
          this.userIFOService.Userpower.asObservable()
          .subscribe(async userpower => {
            this.titlelist = ['NA', 'NA', 'NA' , 'NA' ];
            const data = [[0, 1], [0, 1], [0, 1], [0, 1]];
            const data2 = [0, 0, 0, 0];
            this.datashows = [];
            let sitelist: string[] = [];
            if (userSite === 'All') {  //site為All時
              this.offshow = true;
              sitelist = await userpower.split(',');
            } else {  //單個site
              // this.offshow = true;
              this.offshow = false;
              // 原來不顯示
              sitelist.push(userSite);
            }
            // this.showtitles = sitelist;
            if (sitelist.length <= 4) {
                //  this.Alloff = true;
                  this.Alloff = false;
                  // 页数
                  this.nowpages = 1;
                  this.totalpages = 1;
                  this.pagesremainder = 0;
                  this.loading.patchisloding.next(false);
                  // tslint:disable-next-line: prefer-for-of
                  for (let i = 0; i < sitelist.length; i++) {
                    this.titlelist[i] = sitelist[i];
                    const computernamelist = await this.Computername(sitelist[i]);
                    const  datas = await this.chaxun(sitelist[i]);
                    this.datashows[i] = [datas, computernamelist.length];
                    }
            } else {
                if (sitelist.length % 4 === 0) {
                  const total = sitelist.length / 4;

                  // tslint:disable-next-line: radix
                  this.totalpages = parseInt(total.toString());

                } else {
                  const total = sitelist.length / 4;

                  // tslint:disable-next-line: radix
                  this.totalpages = parseInt(total.toString()) + 1;
                  this.pagesremainder =  sitelist.length % 4;
                }
                await this.paging(sitelist);

            }
            for (let i = 0; i < this.datashows.length; i++) {
              if (this.datashows[i][0] !== undefined) {
                if (this.datashows[i][1] !== 0) {
                  data[i] = this.datashows[i];
                  data2[i] = this.datashows[i][1];
                } else {
                  data[i][1] = 1;
                  data2[i] = 0;
                }
              }
            }
             // 名稱
            this.appname1 = 'ALL';
            this.appname2 = this.titlelist[0];
            this.appname3 = this.titlelist[1];
            this.appname4 = this.titlelist[2];
            this.appname5 = this.titlelist[3];
            // 总数
            this.apptotal2 = data2[0].toString();
            this.apptotal3 = data2[1].toString();
            this.apptotal4 = data2[2].toString();
            this.apptotal5 = data2[3].toString();

            this.apprate2 = ((data[0][0] / data[0][1]) * 100).toFixed(0);
            this.GXtotal2 = data[0][0];
            this.apprate3 = ((data[1][0] / data[1][1]) * 100).toFixed(0);
            this.GXtotal3 = data[1][0];
            this.apprate4 = ((data[2][0] / data[2][1]) * 100).toFixed(0);
            this.GXtotal4 = data[2][0];
            this.apprate5 = ((data[3][0] / data[3][1]) * 100).toFixed(0);
            this.GXtotal5 = data[3][0];


            this.QTtotal2 = data[0][1] - data[0][0];
            this.QTtotal3 = data[1][1] - data[1][0];
            this.QTtotal4 = data[2][1] - data[2][0];
            this.QTtotal5 = data[3][1] - data[3][0];
            this.loading.patchisloding.next(true);
            resolve();
          });

      });
    });
  }


  public async chaxun(site: string): Promise<any> {
    return new Promise<any>(async (resolve, reject) => {
      let total = 0;
      const localrelust = this.pacth.counttotal('"' + site + '"').toPromise();
      //客製化一個API
      // console.log(localrelust);
      localrelust.then(async data => {
        total = await data['counts'][0][''];
        resolve(total);
      });
      // resolve(result);
    });
  }


  // Computername查询
  public async Computername( site: string) {
    const namelist = [];
    const namedata = this.computername.find({where: {Sitename: site}}).toPromise();
    (await namedata).forEach(data => {
        namelist.push(Object.values(data)[0]);
    });
    // console.log(site);
    // console.log(namelist);
    return namelist;
  }

  // Computername查询
  public async ComputernameALL( site: string) {
      const namelist = [];
      const namedata = this.computername.find({where: {Sitename: {inq: site}}}).toPromise();
      (await namedata).forEach(data => {
          namelist.push(Object.values(data)[0]);
      });
      // console.log(site);
      // console.log(namelist);
      return namelist;
    }



   // 分页查询功能
 public paging(site: any ): Promise<any> {
  return new Promise<any>(async (resolve, reject) => {
        if (this.nowpages === 1) {
          this.Alloff = true;
          if (this.queryOne) {
              const ComputerAlllist = await this.ComputernameALL(site);
              // console.log('ComputerAlllist');
              // console.log(ComputerAlllist);
              this.apptotal1 = ComputerAlllist.length;
              let  Alldatas = 0;
              for (let i = 0;  i < site.length; i++) {
                Alldatas += await this.chaxun(site[i]);
              }
              this.apprate1 = ((Alldatas / ComputerAlllist.length) * 100).toFixed(0);
              this.GXtotal1 = Alldatas;
              this.QTtotal1 = ComputerAlllist.length - this.GXtotal1;
              this.queryOne = false;
        }
        } else {
          this.Alloff = false;
        }
        // console.log('Alldatas');
        // console.log(Alldatas);
        // 总页数：this.totalpages； 最后页的个数： this.pagesremainder
        // 当前页数与总页数的判断; 当前页数<总页数 的业务逻辑
        if (await this.nowpages < await this.totalpages) {
            const Queryfisrtindex = await this.nowpages * 4 - 4;
            const Queryendindex = await this.nowpages * 4;
            let j = 0;
            this.datashows = [];
            // 遍歷管理的App簡稱
            for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
                this.titlelist[j] = site[i];
                const computernamelist = await this.Computername(site[i]);
                const  datas = await this.chaxun(site[i]);
                this.datashows.push([datas, computernamelist.length]);
                j++;
               }


        } else {
          // 当前页数与总页数的判断; 当前页数=总页数 的业务逻辑
          // const Queryfisrtindex = await this.nowpages * 4 - 4;
              this.datashows = [];
              // 是否有余数; 有余数时
              if (this.pagesremainder > 0) {
                const Queryfisrtindex = await this.nowpages * 4 - 4;
                let j = 0;

                for (let i = Queryfisrtindex;  i < Queryfisrtindex + this.pagesremainder; i++) {
                  this.titlelist[j] = site[i];
                  const computernamelist = await this.Computername(site[i]);
                  const  datas = await this.chaxun(site[i]);
                  this.datashows.push([datas, computernamelist.length]);
                  j++;
              }
                } else {
                // 没有有余数时
                const Queryfisrtindex = await this.nowpages * 4 - 4;
                const Queryendindex = await this.nowpages * 4;
                let j = 0;
                // 遍歷管理的App簡稱
                for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
                  this.titlelist[j] = site[i];
                  const computernamelist = await this.Computername(site[i]);
                  const  datas = await this.chaxun(site[i]);
                  this.datashows.push([datas, computernamelist.length]);
                  j++;
              }
          }
        }
        resolve();
  });
 }


  public async uppages() {
    this.nowpages --;
    if (this.nowpages < 1) {
      this.nowpages = 1;
      return;
    }
    this.patchQuery();

}

  public async nextpages() {
      this.nowpages ++;
      if (this.nowpages > this.totalpages) {
        this.nowpages = this.totalpages;
        return;
      }
      this.patchQuery();
  }

  //調整新窗口，判斷當前是哪個模塊的點擊事件
  async onChartInit(e) {
    let check = 2;
    let site = e.currentTarget.previousElementSibling.innerHTML;
    // let h15 = 'GDC';
    // console.log("獲取點擊的site"+h15);
    //  this.pacth.find({where: {Sitename: h15}}).toPromise();
    // let url= 'http://localhost:4200/#/tabindex';
    // alert("現在是一個點擊事件");

    window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+site);


  }

  // public async chaxundatapath(site: string) {
  //   const namelistw = [];
  //   const localinfo = await this.pacth.datalistpatch('"' + site + '"').toPromise();
  //   // console.log(localinfo['counts']);
  //   (localinfo['counts']).forEach(element => {
  //     console.log(element);
  //   });
  //   return namelistw;
  // }

}


