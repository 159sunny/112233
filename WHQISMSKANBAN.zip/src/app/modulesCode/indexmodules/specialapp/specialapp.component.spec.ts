import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialappComponent } from './specialapp.component';

describe('SpecialappComponent', () => {
  let component: SpecialappComponent;
  let fixture: ComponentFixture<SpecialappComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecialappComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialappComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
