import { Component, OnInit, OnDestroy } from '@angular/core';
import { V_specificAppApi, V_AutoAPPnamekeyApi, AutoAPPversionApi, V_ComputernameApi } from '../../../service/api/index';

import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';
import { LoadingService } from 'src/app/service/loadings/loading.service';


@Component({
  selector: 'app-specialapp',
  templateUrl: './specialapp.component.html',
  styleUrls: ['./specialapp.component.scss']
})
export class SpecialappComponent implements OnInit, OnDestroy  {
  private subscription: Subscription;

  // 呈現名稱
  appname1: any;
  appname2: any;
  appname3: any;
  appname4: any;
  // 软体数量
  GXtotal1: any = 0;
  GXtotal2: any = 0;
  GXtotal3: any = 0;
  GXtotal4: any = 0;

  QTtotal1: any = 1;
  QTtotal2: any = 1;
  QTtotal3: any = 1;
  QTtotal4: any = 1;
  // app总数
  apptotal1: any ;
  apptotal2: any ;
  apptotal3: any ;
  apptotal4: any ;
  // app占用率
  apprate1: any ;
  apprate2: any ;
  apprate3: any ;
  apprate4: any ;

  // 页数
  nowpages: any = 1;
  totalpages: any = 1;
  pagesremainder: any = 0;
  appkeynamelist: any;
  titlename: any;
  appinfolist: any;

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }

  constructor(
    private specificAppApi: V_specificAppApi,
    private autoAPPnamekeyApi: V_AutoAPPnamekeyApi,
    private autoAPPversionApi: AutoAPPversionApi,
    private computername: V_ComputernameApi,
    private userInfoService: UserIFOService,
    private loading: LoadingService
    ) { }

  async ngOnInit() {
  await this.siteselect();
  }


  /**
   * @method public 查询app
   * @returns 回传App相关资讯
   * @CREATE 2019-12-12 13:07:59
   * @author Jun L Li
   */

    public async queryrsult(site: any) {
        const appreuslt =  await this.Computertotal(site);
        // console.log(appreuslt);
        // 查询需呈现的APP的name
        this.appkeynamelist = await this.Appkeyname();
        this.titlename = ['NA', 'NA', 'NA', 'NA'];
        this.GXtotal1 = 0;
        this.GXtotal2 = 0;
        this.GXtotal3 = 0;
        this.GXtotal4 = 0;

        this.QTtotal1 = 1;
        this.QTtotal2 = 1;
        this.QTtotal3 = 1;
        this.QTtotal4 = 1;
        // 对应server安装相关软体的情况，其单位时一台server
        this.appinfolist = [0, 0, 0, 0];
        if (this.appkeynamelist.length < 5 ) {
          /*
           * App軟體模塊數據呈現邏輯
           * 1.遍歷管理App的簡稱
           * 2.遍歷APP簡稱對應的APP全稱
           * 3.遍歷查詢的Site
           * 4.遍歷site對應的servername
           * 5.查詢server對應安裝的軟體數
           * 6.顯示顯影APP的比率（基本單元為server）
           */
          // 遍歷管理的App簡稱i
          for (let i = 0; i < this.appkeynamelist.length ; i++) {
              this.titlename[i] = await this.appkeynamelist[i];
              this.appinfolist[i] =  await this.Appchaxun(this.appkeynamelist[i], site);
        }

        } else {
        const lengths = await this.appkeynamelist.length / 3;
        // tslint:disable-next-line: radix
        this.totalpages = await parseInt(lengths.toString());
        if (this.appkeynamelist.length % 3 > 0) {
          await this.totalpages ++;
          this.pagesremainder = await this.appkeynamelist.length % 3;
        }
        await this.paging(site);
        }
        this.appname1 = this.titlename[0];
        this.appname2 = this.titlename[1];
        this.appname3 = this.titlename[2];
        this.appname4 = this.titlename[3];

        this.apprate1 = ((this.appinfolist[0] / appreuslt) * 100).toFixed(0);
        this.GXtotal1 = this.appinfolist[0];
        this.apprate2 = ((this.appinfolist[1] / appreuslt) * 100).toFixed(0);
        this.GXtotal2 = this.appinfolist[1];
        this.apprate3 = ((this.appinfolist[2] / appreuslt) * 100).toFixed(0);
        this.GXtotal3 = this.appinfolist[2];
        this.apprate4 = ((this.appinfolist[3] / appreuslt) * 100).toFixed(0);
        this.GXtotal4 = this.appinfolist[3];

        console.log("數組打印"+ this.appinfolist);

        this.QTtotal1 = appreuslt - this.appinfolist[0];
        this.QTtotal2 = appreuslt - this.appinfolist[1];
        this.QTtotal3 = appreuslt - this.appinfolist[2];
        this.QTtotal4 = appreuslt - this.appinfolist[3];

        // this.apptotal2 = await total;
        this.apptotal1 = appreuslt;
        this.apptotal2 = appreuslt;
        this.apptotal3 = appreuslt;
        this.apptotal4 = appreuslt;
    }

  public async Appchaxun(Appname: string[], sitename: string[]) {
    const chaxunapptotal = await this.specificAppApi.count(
      {and: [
        {APPnameKey:  Appname},
        {Sitename: {inq: sitename}}
      ]}
    ).toPromise();
    const chaxunreuslt = chaxunapptotal.count;

    return chaxunreuslt;
  }



  // 查询名称（簡稱）
  public async Appkeyname() {
      const keynamelist: string[] = [];
      const keyname = await this.autoAPPnamekeyApi.find().toPromise();
      keyname.forEach(async data => {
        keynamelist.push( await Object.values(data).toString());
      });
      return keynamelist;
  }

  // app的全稱
  public async Appversion( nameKey: string) {
      const versionlist: string[] = [];
      const version = await this.autoAPPversionApi.find({where: {APPnameKey: nameKey}}).toPromise();
      version.forEach(data => {
        versionlist.push(Object.values(data)[0]);
       });
      return versionlist;
  }





  public async siteselect(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
      let sitedatalist = [];
      this.userInfoService.UserSite
      .asObservable()
      .subscribe(async site => {
        this.loading.AppIsloding.next(false);
        if (site === 'All') {
          sitedatalist = await this.sitelist();
        } else {
          sitedatalist = [site];
        }
        await  this.queryrsult(sitedatalist);
        this.loading.AppIsloding.next(true);
      });
      // console.log(sitedatalist);
      resolve(sitedatalist);
  });
  }



  private sitelist(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist: string[] = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }




 // 分页查询功能
 public paging(site: string[]): Promise<any> {
  return new Promise<any>(async (resolve, reject) => {
        // 总页数：this.totalpages； 最后页的个数： this.pagesremainder
        // 当前页数与总页数的判断; 当前页数<总页数 的业务逻辑
        if (await this.nowpages < await this.totalpages) {
          const Queryfisrtindex = await this.nowpages * 3 - 3;
          const Queryendindex = await this.nowpages * 3;
          let j = 0;
          // 遍歷管理的App簡稱
          for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
              this.titlename[j] = await this.appkeynamelist[i];
              this.appinfolist[j] =  await this.Appchaxun(this.appkeynamelist[i], site);
              j++;
        }


      } else {
        // 当前页数与总页数的判断; 当前页数=总页数 的业务逻辑
        // const Queryfisrtindex = await this.nowpages * 4 - 4;
            // 是否有余数; 有余数时
            if (this.pagesremainder > 0) {
              const Queryfisrtindex = await this.nowpages * 3 - 3;
              let j = 0;
              // 遍歷管理的App簡稱
              for (let i = Queryfisrtindex;  i < Queryfisrtindex + this.pagesremainder; i++) {
                this.titlename[j] = await this.appkeynamelist[i];
                this.appinfolist[j] =  await this.Appchaxun(this.appkeynamelist[i], site);
                j++;
              }
              } else {
              // 没有有余数时
              const Queryfisrtindex = await this.nowpages * 3 - 3;
              const Queryendindex = await this.nowpages * 3;
              let j = 0;
              // 遍歷管理的App簡稱
              for (let i = Queryfisrtindex;  i < Queryendindex; i++) {
                this.titlename[j] = await this.appkeynamelist[i];
                this.appinfolist[j] =  await this.Appchaxun(this.appkeynamelist[i], site);
                j++;
            }
        }
      }
        resolve();
  });
 }


  public async uppages() {
    this.nowpages --;
    if (this.nowpages < 1) {
      // alert('这已经是第一页了');
      this.nowpages = 1;
      return;
    }
    await this.siteselect();

}

  public async nextpages() {
      this.nowpages ++;
      if (this.nowpages > this.totalpages) {
        // alert('这已经是最后一页了');
        this.nowpages = this.totalpages;
        return;
      }
      await this.siteselect();
  }

  // Computername查询
  public async Computername( site: string) {
    const namelist = [];
    const namedata = this.computername.find({where: {Sitename: {inq: site}}}).toPromise();
    (await namedata).forEach(data => {
        namelist.push(Object.values(data)[0]);
    });
    return namelist;
  }


  // Computername查询
  public async Computertotal( site: string[]) {
    let namelist = 0;
    const namedata = this.computername.count({Sitename: {inq: site}}).toPromise();
    namelist += (await namedata).count;
    return namelist;
  }

  async onChartInit(e) {
    let check = 9;
    let site = e.currentTarget.previousElementSibling.innerHTML;
    window.open("http://localhost:4200/#/tabindex?check="+ check+"&"+"site="+site);
  }

}
