import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServertotalsComponent } from './servertotals.component';

describe('ServertotalsComponent', () => {
  let component: ServertotalsComponent;
  let fixture: ComponentFixture<ServertotalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServertotalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServertotalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
