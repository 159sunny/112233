import { Component, OnInit, OnDestroy, Input , SimpleChanges, OnChanges, ViewChild, SystemJsNgModuleLoader} from '@angular/core';
import {V_AutoCompareComputerInfoApi, V_TwoUltiomServertotalApi, V_UltiomServertotalApi, V_AutoCompareComputerInfo} from '../../../service/api/index';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';
import { LoadingService } from 'src/app/service/loadings/loading.service';

@Component({
  selector: 'app-servertotals',
  templateUrl: './servertotals.component.html',
  styleUrls: ['./servertotals.component.scss']
})


export class ServertotalsComponent implements OnInit, OnDestroy {

  private subscription: Subscription;

  // fottitlelist: any = ['product', 'WHQ', 'WZS', 'WKS', 'WCQ', 'WOK' , 'WCD'];
  // fottitle1data: any = ['8月份', 100, 30, 90, 50, 70 , 20];
  // fottitle2data: any = ['9月份', 86, 92, 60, 60, 90 , 40];
  // fottitle3data: any = ['10月份', 86, 92, 70, 55, 42 , 80];
  site: any;
  fottitlelist: any;  //命名echart的變量
  fottitle1data: any;
  fottitle2data: any;
  fottitle3data: any;
  fottitle4data: any;
  servertotals: any;

  // 页数
  nowpages: any = 1;
  totalpages: any = 1;
  pagesremainder: any = 0;
  Alloff = false;
  queryOne = true;

  constructor(  //定義導入的API
    private servertotal: V_AutoCompareComputerInfoApi,
    private userInfoService: UserIFOService,
    private TwoUltiomServertotal: V_TwoUltiomServertotalApi,
    private UltiomServertotal: V_UltiomServertotalApi,
    private loading: LoadingService
  ) { }


  shuaxin: any;
  async ngOnInit() {
      await this.listenSite();
  }



  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }

//當頁面選擇為單個site時
  public chaxun(site: string, nowmonth: string, mouth1: string, month2: string): Promise<any[]> {
    return new Promise<any[]>(async (resolve, reject) => {
      const result1 = await this.servertotal.count(
        {
          and: [
            {Sitename: site}
          ]
        }).toPromise();
      const nowmonthresult = result1.count;
      const result2 = await this.UltiomServertotal.count(
        {
          and: [
            {Sitename: site}
          ]
        }).toPromise();
      const month1result = result2.count;
      const result3 = await this.TwoUltiomServertotal.count(
        {
          and: [
            {Sitename: site}
          ]
        }).toPromise();
      const month2result = result3.count;
      const data = [nowmonthresult, month1result, month2result];
      resolve(data);
    });
  }

//選擇All時  頁面加載時出現all，是與上面的區別
  public chaxunAll(site: string, nowmonth: string, mouth1: string, month2: string): Promise<any[]> {
    return new Promise<any[]>(async (resolve, reject) => {
      const result1 = await this.servertotal.count(
        {
          and: [
            {Sitename: {inq: site}}   // inq运算符检查指定属性的值是否与数组中提供的任何值匹配 lookback的數據庫查詢
          ]
        }).toPromise();
      const nowmonthresult = result1.count; //當月累計的數量
      const result2 = await this.UltiomServertotal.count(
        {
          and: [
            {Sitename: {inq: site}}
          ]
        }).toPromise();
      const month1result = result2.count;
      const result3 = await this.TwoUltiomServertotal.count(
        {
          and: [
            {Sitename: {inq: site}}
          ]
        }).toPromise();
      const month2result = result3.count;
      const data = [nowmonthresult, month1result, month2result];
      resolve(data);
    });
  }
  private listenSite(): Promise<any[]> {
    return new Promise<any[]>((resolve, reject) => {
      const subscription = this.userInfoService.UserSite
      .asObservable()
      .subscribe(async site => {
        let sitelist = [];
        this.loading.servertotalIsloading.next(false);  //先賦值頁面load為false
        this.site = site;
        const date = new Date();   //獲取當前的時間
        const nowyear = date.getFullYear();  // 獲取當前時間的年份
        let nowmonth ;
        let mouth1 ;
        let month2 ;
        this.fottitlelist = ['product'];
        if (date.getMonth() !== 0 && date.getMonth() !== 1) {
          nowmonth = nowyear + '/' + (date.getMonth() + 1);
          mouth1 = nowyear + '/' + date.getMonth();
          month2 = nowyear + '/' + (date.getMonth() - 1);
          // this.fottitle1data = [(date.getMonth() + 1) + '月份'];
          //  this.fottitle2data = [date.getMonth() + '月份'];
          // this.fottitle3data = [(date.getMonth() - 1) + '月份'];
          // this.fottitle1data = [new Date(new Date().setMonth(date.getMonth())).toLocaleString( 'en-us',{ month: 'long' })];
          // alert(m1);//当前月
          // this.fottitle2data = [new Date(new Date().setMonth(date.getMonth() - 1)).toLocaleString('en-us',{ month: 'long' })];
          // alert(m2);//前一月
          // this.fottitle3data = [new Date(new Date().setMonth(date.getMonth() - 2)).toLocaleString('en-us',{ month: 'long' })];
          //月份英文簡體
          // this.fottitle1data = [new Date(new Date().setMonth(date.getMonth())).toLocaleString( 'en-us',{ month: 'long' })];
          // alert(m1);//当前5月



          this.fottitle1data = [new Date(new Date().setMonth(date.getMonth())).toDateString().split(" ")[1]];
          this.fottitle2data = [new Date(new Date().setMonth(date.getMonth() - 1)).toDateString().split(" ")[1]];
          // alert(m2);//前一月
          this.fottitle3data = [new Date(new Date().setMonth(date.getMonth() - 2)).toDateString().split(" ")[1]];
           if (this.fottitle1data !='May' ||this.fottitle2data !='May'||this.fottitle3data !='May') {

            this.fottitle1data = [new Date(new Date().setMonth(date.getMonth())).toDateString().split(" ")[1] + '.'];
          this.fottitle2data = [new Date(new Date().setMonth(date.getMonth() - 1)).toDateString().split(" ")[1] + '.'];
          // alert(m2);//前一月
          this.fottitle3data = [new Date(new Date().setMonth(date.getMonth() - 2)).toDateString().split(" ")[1] + '.'];

           }

        } else if (date.getMonth() === 0){
          nowmonth = nowyear + '/' + (date.getMonth() + 1);
          mouth1 = (nowyear - 1) + '/' + 12;
          month2 = (nowyear - 1) + '/' + 11;
          this.fottitle1data = [(date.getMonth() + 1)];
          this.fottitle2data = [12 ];
          this.fottitle3data = [11];
          // this.fottitle1data = [(date.getMonth() + 1).CultureInfo("en-us") ];
          // this.fottitle2data = [12 + '月份'];
          // this.fottitle3data = [11 + '月份'];
        } else {
          nowmonth = nowyear + '/' + (date.getMonth() + 1);
          mouth1 = nowyear + '/' + date.getMonth();
          month2 = (nowyear - 1) + '/' + 12;
          // this.fottitle1data = [(date.getMonth() + 1) + '月份'];
          // this.fottitle2data = [date.getMonth() + '月份'];
          // this.fottitle3data = [12 + '月份'];
          this.fottitle1data = [(date.getMonth() + 1)];
          this.fottitle2data = [date.getMonth()];
          this.fottitle3data = [12];
        }
        if (this.site === 'All') {
          sitelist = await this.userpower();
          if (sitelist.length % 5 === 0) {
            const total = sitelist.length / 5;
            // tslint:disable-next-line: radix
            this.totalpages = parseInt(total.toString());

          } else {
            const total = sitelist.length / 5;
            // tslint:disable-next-line: radix
            this.totalpages = parseInt(total.toString()) + 1;
            this.pagesremainder =  sitelist.length % 5;
          }
          await this.paging(sitelist, nowmonth, mouth1, month2);


        } else {
          this.nowpages = 1;
          this.totalpages = 1;
          sitelist[0] = site;
          await this.paging(sitelist, nowmonth, mouth1, month2);
        }
        this.servertotals = [this.fottitlelist, this.fottitle3data , this.fottitle2data , this.fottitle1data];
        // let y = new Date().setMonth((date.getMonth()));
        //  console.log('月份1' + new Date().setTime(y));
        // console.log('月份2' + date.getMonth());

        // let date1=new Date();
        // console.log(date1.toDateString());
        // console.log(date1.toDateString().split(" ")[1]);
        // console.log('this.servertotals');
        // console.log(this.servertotals);
        // console.log('Site', site);
        //  console.log(date.getMonth().)
        this.loading.servertotalIsloading.next(true);
        resolve(this.servertotals);
      }, error => {
        // console.error(error);
        reject(error);
      });

      if (this.subscription !== undefined) {
        this.subscription.add(subscription);
      } else {
        this.subscription = subscription;
      }
    });
  }


  public async paging(sitelist: any, nowmonth: any, mouth1: any, month2: any) {
    let sitedata: any;
    if (this.nowpages === 1 && sitelist.length > 1) {
      this.Alloff = true;
      sitedata = await this.chaxunAll(sitelist, nowmonth, mouth1, month2);
      // window.console.log('sitedataAll');
      // window.console.log(sitedata);
      this.fottitlelist.push('ALL');
      this.fottitle1data.push(sitedata[0]);
      this.fottitle2data.push(sitedata[1]);
      this.fottitle3data.push(sitedata[2]);
    } else {
      this.Alloff = false;
    }
    // tslint:disable-next-line: prefer-for-of
    if (this.nowpages < this.totalpages) {
      for (let i = await this.nowpages * 5 - 5; i < await this.nowpages * 5; i++) {
        sitedata = await this.chaxun(sitelist[i], nowmonth, mouth1, month2);
        this.fottitlelist.push(sitelist[i]);
        this.fottitle1data.push(sitedata[0]);
        this.fottitle2data.push(sitedata[1]);
        this.fottitle3data.push(sitedata[2]);
      }
    } else if (this.nowpages === this.totalpages && this.nowpages === 1) {
      sitedata = await this.chaxun(sitelist[0], nowmonth, mouth1, month2);
      this.fottitlelist.push(sitelist[0]);
      this.fottitle1data.push(sitedata[0]);
      this.fottitle2data.push(sitedata[1]);
      this.fottitle3data.push(sitedata[2]);
    } else {
      if (this.pagesremainder > 0) {
        for (let i = await this.nowpages * 5 - 5; i < (await this.nowpages * 5 - 5 + this.pagesremainder); i++) {
          sitedata = await this.chaxun(sitelist[i], nowmonth, mouth1, month2);
          this.fottitlelist.push(sitelist[i]);
          this.fottitle1data.push(sitedata[0]);
          this.fottitle2data.push(sitedata[1]);
          this.fottitle3data.push(sitedata[2]);
        }
      } else {
        for (let i = await this.nowpages * 5 - 5; i < await this.nowpages * 5; i++) {
          sitedata = await this.chaxun(sitelist[i], nowmonth, mouth1, month2);
          this.fottitlelist.push(sitelist[i]);
          this.fottitle1data.push(sitedata[0]);
          this.fottitle2data.push(sitedata[1]);
          this.fottitle3data.push(sitedata[2]);
        }
      }
    }
  }


  private userpower(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }


  public async uppages() { //上一頁
    this.nowpages --;
    if (this.nowpages < 1) {
      this.nowpages = 1;
      return;
    }
    await this.listenSite();


  }

  public async nextpages() {  //下一頁
      this.nowpages ++;
      if (this.nowpages > this.totalpages) {
        this.nowpages = this.totalpages;
        return;
      }
      await this.listenSite();
  }




}




