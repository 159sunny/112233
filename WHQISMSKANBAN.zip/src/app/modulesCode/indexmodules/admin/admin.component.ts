import { Component, OnInit,  OnDestroy, DebugElement} from '@angular/core';


import { V_admintotalApi} from '../../../service/api/index';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { Subscription } from 'rxjs';
import { LoadingService } from 'src/app/service/loadings/loading.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit,  OnDestroy {
  center: any = ['50%', '50%'];
  radius: any = [0, '55%'];
  showtitles: any = ['Less than 3', '4~7', 'More than 8'];
  // showtitles: any = ['3个账号以下', '4~7个账号', '8个账号以上'];
  datashows: any = [];
  private subscription: Subscription;
  constructor(
    private userInfoService: UserIFOService,
    private todayadmintotal: V_admintotalApi,
    private loading: LoadingService
  ) { }

  async ngOnInit() {
    await this.querytodaydata();
  }

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }


  public querytodaydata(): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
      this.userInfoService.UserSite.asObservable()
      .subscribe(async site => {
          this.loading.adminisloding.next(false);
          const AdminTotalArray = await this.todaydata(site);
          this.datashows = [
            {value: AdminTotalArray[0], name: 'Less than 3'},
            {value: AdminTotalArray[1], name: '4~7'},
            {value: AdminTotalArray[2], name: 'More than 8'}
          ];
          this.loading.adminisloding.next(true);
      });
      resolve();
    });
  }

  public todaydata(sitename: string): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
        // 3个以下
        let total1 = 0;
        // 4~7个
        let total2 = 0;
        // 8个以上
        let total3 = 0;
        if (sitename === 'All') {
          const sitelist = await this.sitelist();
          // tslint:disable-next-line: prefer-for-of
          for (let i = 0; i < sitelist.length; i++) {
              const datalist = this.todayadmintotal.find(
                {where: {Sitename: sitelist[i]}}
                ).toPromise();
              (await datalist).forEach(data => {
                if (Object.values(data)[1] <= 3 ) {
                  total1++;
                } else if (Object.values(data)[1] >= 8 ) {
                  total3++;
                } else {
                  total2++;
                }
                // console.log(Object.values(data)[1]);
              });
            }
        } else {
          const datalist = this.todayadmintotal.find(
            {where: {Sitename: sitename}}
            ).toPromise();
          (await datalist).forEach(data => {
            window.console.log('datalist');
            window.console.log(data);
            if (Object.values(data)[1] <= 3 ) {
              total1++;
            } else if (Object.values(data)[1] >= 8 ) {
              total3++;
            } else {
              total2++;
            }
          });
        }
        const dataArray = [total1, total2, total3];
        resolve(dataArray);
    });
  }


  private sitelist(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist: string[] = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }


}
