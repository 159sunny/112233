import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmintotalchangeComponent } from './admintotalchange.component';

describe('AdmintotalchangeComponent', () => {
  let component: AdmintotalchangeComponent;
  let fixture: ComponentFixture<AdmintotalchangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmintotalchangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmintotalchangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
