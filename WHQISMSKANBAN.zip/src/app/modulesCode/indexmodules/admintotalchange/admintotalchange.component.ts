import { Component, OnInit,  OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import { V_admintotaldaybeforeApi, V_admintotalApi} from '../../../service/api/index';
import { UserIFOService } from '../../objectmodules/user-ifo.service';
import { LoadingService } from 'src/app/service/loadings/loading.service';


@Component({
  selector: 'app-admintotalchange',
  templateUrl: './admintotalchange.component.html',
  styleUrls: ['./admintotalchange.component.scss']
})
export class AdmintotalchangeComponent implements OnInit,  OnDestroy {
  actualtotal: any = 0;
  rawtotal: any = 0;
  downtotal: any = 0;
  uptotal: any = 0;
  downbarstatus: any = false;
  upbarstatus: any = false;
  private subscription: Subscription;
  constructor(
    private userInfoService: UserIFOService,
    private todayadmintotal: V_admintotalApi,
    private berforadmintotal: V_admintotaldaybeforeApi,
    private loading: LoadingService
  ) { }

 async  ngOnInit() {
   await this.changereustl();
  }

  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }


  public changereustl(): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
        this.userInfoService.UserSite.asObservable()
        .subscribe(async site => {
              this.loading.adminchangeisloading.next(false);
              let todaytotal = 0;
              let berfortotal = 0;
              if (site === 'All') {
                const sitelist = await this.sitelist();
                // tslint:disable-next-line: prefer-for-of
                for (let i = 0; i < sitelist.length; i++) {
                  todaytotal += await this.todaydata(sitelist[i]);

                  berfortotal += await this.berfordata(sitelist[i]);

                }
                console.log("現在的賬戶數量"+todaytotal);
                console.log("今天之前的賬戶數量"+berfortotal);
                this.loading.adminchangeisloading.next(true);
              } else {
                 todaytotal += await this.todaydata(site);
                 berfortotal += await this.berfordata(site);
                 this.loading.adminchangeisloading.next(true);
              }
              this.rawtotal = berfortotal;
              if (todaytotal > berfortotal) {
                this.uptotal = todaytotal - berfortotal; //增加的數量
                this.downtotal = 0; //減少的數量
                // this.actualtotal = berfortotal;
                this.actualtotal = todaytotal;
                this.downbarstatus = false;
                this.upbarstatus = true;
              }
              if (todaytotal < berfortotal) {
                this.uptotal = 0;
                this.downtotal = berfortotal - todaytotal ;
                this.actualtotal = berfortotal - this.downtotal;
                this.downbarstatus = true;
                this.upbarstatus = false;
              }

              if (todaytotal === berfortotal) {
                this.uptotal = 0;
                this.downtotal = 0 ;
                this.actualtotal = berfortotal;
                this.downbarstatus = false;
                this.upbarstatus = false;
              }

        });

        resolve();
    });
  }


  public todaydata(sitename: string): Promise<any> {
    return new Promise<any> (async (resolve, reject) => {
        let total = 0;
        const datalist = this.todayadmintotal.find(
          {where: {Sitename: sitename}}
          ).toPromise();
        (await datalist).forEach(data => {
          if (Object.values(data)[1] > 0) {
            total ++;
          }
        });
        resolve(total);
    });
  }



  public berfordata(sitename: string): Promise<any> {
      return new Promise<any> (async (resolve, reject) => {
          let total = 0;
          const datalist = this.berforadmintotal.find(
            {where: {Sitename: sitename}}
            ).toPromise();
          (await datalist).forEach(data => {
            if (Object.values(data)[1] > 0) {
              total ++;
            }
          });
          // console.log(total);
          resolve(total);
      });
  }


  private sitelist(): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        let sitelist: string[] = [];
        this.userInfoService.Userpower.asObservable()
        .subscribe(async site => {
            sitelist = await site.split(',');
            resolve(sitelist);
        });
    });
  }


}
