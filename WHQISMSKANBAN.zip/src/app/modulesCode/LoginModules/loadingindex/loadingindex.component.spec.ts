import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadingindexComponent } from './loadingindex.component';

describe('LoadingindexComponent', () => {
  let component: LoadingindexComponent;
  let fixture: ComponentFixture<LoadingindexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadingindexComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingindexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
