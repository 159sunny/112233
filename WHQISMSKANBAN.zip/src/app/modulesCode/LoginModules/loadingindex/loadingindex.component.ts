import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoadingService } from '../../../service/loadings/loading.service';

@Component({
  selector: 'app-loadingindex',
  templateUrl: './loadingindex.component.html',
  styleUrls: ['./loadingindex.component.scss']
})
export class LoadingindexComponent implements OnInit,  OnDestroy {
  adminisLoading = false;
  adminchangeisLoading = false;
  localisLoading = false;
  officescanLoading = false;
  PatchisLoading = false;
  servertotalisLoading = false;
  appisLoading = false;
  eosisLoading = false;
  winversion = false;
  private subscription: Subscription;
  constructor(
    private loading: LoadingService
  ) { }
  public  ngOnDestroy(): void {
    if (this.subscription !== undefined) {
      this.subscription.unsubscribe();
    }
  }
  async ngOnInit() {
    await this.loadingreuslt();
  }

  public loadingreuslt(): Promise<any[]> {
    return new Promise<any[]>(async (resolve, reject) => {
      this.loading.adminisloding.asObservable().subscribe(async data => {
        this.adminisLoading = await data;
      });
      this.loading.adminchangeisloading.asObservable().subscribe(async data => {
        this.adminchangeisLoading = await data;
        // console.log('this.adminchangeisLoading');
        // console.log(this.adminchangeisLoading);
      });
      this.loading.localisloding.asObservable().subscribe(async data => {
        this.localisLoading = await data;
      });
      this.loading.officescanIsloading.asObservable().subscribe(async data => {
        this.officescanLoading = await data;
      });
      this.loading.patchisloding.asObservable().subscribe( async data => {
        this.PatchisLoading = await data;
      });
      this.loading.servertotalIsloading.asObservable().subscribe( async data => {
        this.servertotalisLoading = await data;
      });
      this.loading.AppIsloding.asObservable().subscribe( async data => {
        this.appisLoading = await data;
      });
      this.loading.eosIsloading.asObservable().subscribe( async data =>{
        this.eosisLoading = await data;
      });
      this.loading.winVIsloading.asObservable().subscribe( async data => {
        this.winversion = await data;
      });

      resolve();
    });
  }

}
