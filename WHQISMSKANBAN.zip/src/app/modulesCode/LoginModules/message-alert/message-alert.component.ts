import { Component, OnDestroy, Input,  SimpleChanges, SimpleChange} from '@angular/core';

@Component({
  selector: 'app-message-alert',
  templateUrl: './message-alert.component.html',
  styleUrls: ['./message-alert.component.scss']
})
export class MessageAlertComponent implements OnDestroy {

    constructor() { }
    @Input() title: string = '';
    @Input() detail: any = '';
    @Input() isError: boolean = true;
    message: any;
    messageStyle: string = '';
    messageTimeout: any;

    // tslint:disable-next-line: use-lifecycle-interface
    ngOnChanges(changes: SimpleChanges) {
        const detail: SimpleChange = changes.detail;
        if (detail) {
            this.detail = detail.currentValue;
            if (this.detail) {
                this.showError(this.title, this.detail);
            }
        }
    }
    ngOnDestroy() {
        try {
            if (this.messageTimeout) {
                clearTimeout(this.messageTimeout);
            }
        } catch (error) {
            console.log(error);
        }
    }

    showError(title, detail, noTimeout: boolean = false) {
        console.log(title, detail);

        const that = this;
        that.detail = '';
        that.messageStyle = 'alert alert-danger';
        that.message = title + ' Data error';
        if (that.messageTimeout != null) {
            clearTimeout(that.messageTimeout);
            that.messageTimeout = null;
        }
        if (!noTimeout) {
            // tslint:disable-next-line: only-arrow-functions
            that.messageTimeout = setTimeout(function() {
                that.message = null;
            }, 3000);
        }
    }
}
