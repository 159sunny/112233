import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER} from '@angular/core';
import { NgxEchartsModule} from 'ngx-echarts';

import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzTableModule } from 'ng-zorro-antd/table';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeindexComponent } from './UIshows/homeindex/homeindex.component';
import { LoginindexComponent } from './UIshows/loginindex/loginindex.component';
import { ArchcssComponent } from './echartsTool/archtools/archcss/archcss.component';
import { BarthreeComponent } from './echartsTool/bartools/barthree/barthree.component';
import { LoopappComponent } from './echartsTool/looptools/loopapp/loopapp.component';
import { PiechartsComponent } from './echartsTool/pietools/piecharts/piecharts.component';
import { AdminComponent } from './modulesCode/indexmodules/admin/admin.component';
import { LocalComponent } from './modulesCode/indexmodules/local/local.component';
import { OfficescanComponent } from './modulesCode/indexmodules/officescan/officescan.component';
import { PatchComponent } from './modulesCode/indexmodules/patch/patch.component';
import { ServertotalsComponent } from './modulesCode/indexmodules/servertotals/servertotals.component';
import { SiteeosComponent } from './modulesCode/indexmodules/siteeos/siteeos.component';
import { SpecialappComponent } from './modulesCode/indexmodules/specialapp/specialapp.component';
import { WinversionComponent } from './modulesCode/indexmodules/winversion/winversion.component';
import { LoopeosComponent } from './echartsTool/looptools/loopeos/loopeos.component';
import { AdmintotalchangeComponent } from './modulesCode/indexmodules/admintotalchange/admintotalchange.component';
import { ConfigloadService } from './service/configservice/configload.service';
import { HttpClientModule } from '@angular/common/http';

// 表单
import { FormsModule } from '@angular/forms';
import { MessageModalComponent } from './modulesCode/LoginModules/message-modal/message-modal.component';
import { LoadingComponent } from './modulesCode/LoginModules/loading/loading.component';
import { MessageAlertComponent } from './modulesCode/LoginModules/message-alert/message-alert.component';
import { BarpileupComponent } from './echartsTool/bartools/barpileup/barpileup.component';
// SDK
import { SDKBrowserModule } from './service/api/index';

import { UserIFO } from './modulesCode/objectmodules/UserIFO';

import { SessionstorageService } from './service/loadings/sessionstorage.service'
import { LoadingindexComponent } from './modulesCode/LoginModules/loadingindex/loadingindex.component';
import {HashLocationStrategy, LocationStrategy} from '@angular/common';
import { FunneltoolsComponent } from './echartsTool/funneltools/funneltools.component';
import { TabIndexComponent } from './RawDataList/tab-index/tab-index.component';

export function configureProvider(loader: ConfigloadService) {
  return () => loader.loadConfigure([
    { path: '../assets/config/Datasources.json', type: 'datasources' },
  ]);
}

@NgModule({
  declarations: [
    AppComponent,
    HomeindexComponent,
    LoginindexComponent,
    ArchcssComponent,
    BarthreeComponent,
    LoopappComponent,
    PiechartsComponent,
    AdminComponent,
    LocalComponent,
    OfficescanComponent,
    PatchComponent,
    ServertotalsComponent,
    SiteeosComponent,
    SpecialappComponent,
    WinversionComponent,
    LoopeosComponent,
    AdmintotalchangeComponent,
    MessageModalComponent,
    LoadingComponent,
    MessageAlertComponent,
    BarpileupComponent,
    LoadingindexComponent,
    FunneltoolsComponent,
    TabIndexComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxEchartsModule,
    HttpClientModule,
    FormsModule,
    SDKBrowserModule.forRoot(),
    NzButtonModule,
    NzTableModule
  ],
  providers: [
    SessionstorageService,
    UserIFO,
    ConfigloadService,
    {
      provide: APP_INITIALIZER,
      useFactory: configureProvider,
      deps: [ConfigloadService],
      multi: true
    },
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
