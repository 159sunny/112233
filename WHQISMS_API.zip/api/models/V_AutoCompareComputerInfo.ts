/* tslint:disable */

declare var Object: any;
export interface V_AutoCompareComputerInfoInterface {
  "ComputerName"?: string;
  "ipaddress"?: string;
  "updatedate"?: Date;
  "osversion"?: string;
  "ofcntrtscan"?: string;
  "ofctmlisten"?: string;
  "ofcversion"?: string;
  "cpu"?: string;
  "memory"?: string;
  "hdddrivesname"?: string;
  "hddsize"?: string;
  "Sitename"?: string;
}

export class V_AutoCompareComputerInfo implements V_AutoCompareComputerInfoInterface {
  "ComputerName": string;
  "ipaddress": string;
  "updatedate": Date;
  "osversion": string;
  "ofcntrtscan": string;
  "ofctmlisten": string;
  "ofcversion": string;
  "cpu": string;
  "memory": string;
  "hdddrivesname": string;
  "hddsize": string;
  "Sitename": string;
  constructor(data?: V_AutoCompareComputerInfoInterface) {
    Object.assign(this, data);
  }
  /**
   * The name of the model represented by this $resource,
   * i.e. `V_AutoCompareComputerInfo`.
   */
  public static getModelName() {
    return "V_AutoCompareComputerInfo";
  }
  /**
  * @method factory
  * @author Jonathan Casarrubias
  * @license MIT
  * This method creates an instance of V_AutoCompareComputerInfo for dynamic purposes.
  **/
  public static factory(data: V_AutoCompareComputerInfoInterface): V_AutoCompareComputerInfo{
    return new V_AutoCompareComputerInfo(data);
  }
  /**
  * @method getModelDefinition
  * @author Julien Ledun
  * @license MIT
  * This method returns an object that represents some of the model
  * definitions.
  **/
  public static getModelDefinition() {
    return {
      name: 'V_AutoCompareComputerInfo',
      plural: 'V_AutoCompareComputerInfos',
      path: 'V_AutoCompareComputerInfos',
      idName: 'ComputerName',
      properties: {
        "ComputerName": {
          name: 'ComputerName',
          type: 'string'
        },
        "ipaddress": {
          name: 'ipaddress',
          type: 'string'
        },
        "updatedate": {
          name: 'updatedate',
          type: 'Date'
        },
        "osversion": {
          name: 'osversion',
          type: 'string'
        },
        "ofcntrtscan": {
          name: 'ofcntrtscan',
          type: 'string'
        },
        "ofctmlisten": {
          name: 'ofctmlisten',
          type: 'string'
        },
        "ofcversion": {
          name: 'ofcversion',
          type: 'string'
        },
        "cpu": {
          name: 'cpu',
          type: 'string'
        },
        "memory": {
          name: 'memory',
          type: 'string'
        },
        "hdddrivesname": {
          name: 'hdddrivesname',
          type: 'string'
        },
        "hddsize": {
          name: 'hddsize',
          type: 'string'
        },
        "Sitename": {
          name: 'Sitename',
          type: 'string'
        },
      },
      relations: {
      }
    }
  }
}
