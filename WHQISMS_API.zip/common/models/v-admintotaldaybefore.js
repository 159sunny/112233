'use strict';

module.exports = function(Vadmintotaldaybefore) {

  Vadmintotaldaybefore.datalistMonitouGroup = (site, callback) => {
    site=site.replace('[','(');
    site=site.replace(']',')');


let sqldatalist="select computername,username,setpsdate,Sitename from AutoSaveLocalUserGroup_log "+
" WHERE createdate > convert(NVARCHAR, getdate()-1,111) AND  createdate < convert(NVARCHAR, getdate(),111) "+
"and Sitename in ("+site+")"

    console.log(site);
    // var sqldatalist = "select log.computername,log.username,log.setpsdate,log.Sitename from AutoSaveLocalUserGroup_log log left join (SELECT computername,count(computername) admintotal,Sitename FROM AutoSaveLocalUserGroup_log  WHERE createdate > convert(NVARCHAR, getdate()-1,111) AND  createdate < convert(NVARCHAR, getdate(),111) group BY computername,Sitename) utt on log.computername=utt.computername and log.Sitename=utt.Sitename where 1=1 and utt.Sitename in('" + site+ "')";
    console.log("yyyyyyyyyy111");
    console.log('sql:' + sqldatalist);
    console.log("yyyyyyyyyy");
    var connt = Vadmintotaldaybefore.dataSource;
    connt.connector.execute(sqldatalist, function(err, response) {
        console.log(response);
        callback(null, response);

    });
};


Vadmintotaldaybefore.remoteMethod('datalistMonitouGroup', {
  http: {
      path: '/datalistMonitouGroup',
      verb: 'get',
  },
  accepts:[{
    arg:'site',
    type:'string',
    required:true
    }],
  returns: {
    type:'string',
    root:true
  },
});

};
