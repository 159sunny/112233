'use strict';

module.exports = function(Vspecificapp) {
  Vspecificapp.specificappimg = (site,callback) => {
    console.log("WWWWWWWWWWW");
    console.log(site);
    console.log(site['tit']);
    console.log(site['site']);
    console.log(site['tity']);
    console.log("WWWWWWWWWWW");
    var connt = Vspecificapp.dataSource;

    let sql = "SELECT DISTINCT(b.computername),b.Sitename,b.name,b.vendor,b.version,b.installdate,b.createdate "+
    " FROM AutoSaveComputeSoftwareInfo b "+
    " WHERE b.computername IN (select d.computername from v_specificApp d where d.APPnameKey = '"+site['tit']+"' and d.Sitename in("+site['site']+")) "+
    " AND b.name IN (select a.APPname from AutoAPPversion a where a.APPnameKey ='"+site['tity']+"') "+
    " ORDER BY b.createdate DESC";
    // var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "'";
    // console.log('sql:' + sql);
    console.log(site);
    connt.connector.execute(sql, function(err, response) {
      console.log(sql);
        callback(null, response);
    });
};



Vspecificapp.remoteMethod('specificappimg', {
  http: {
    path: '/specificappimg',
    verb: 'post',
},
accepts: {
  arg: 'site',
  type: 'object',
  http: {
      source: 'body',
  },
  required: false,
},
returns: {
    arg: 'counts',
    type: 'object',
},
});
};
