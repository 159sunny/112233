'use strict';

module.exports = function(Autosavelocalusergrouplog) {

};
