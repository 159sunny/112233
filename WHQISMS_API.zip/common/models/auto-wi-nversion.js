'use strict';

module.exports = function(Autowinversion) {

};
