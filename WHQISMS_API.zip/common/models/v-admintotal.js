'use strict';

module.exports = function(Vadmintotal) {

  Vadmintotal.counttotal = (site, callback) => {
    console.log(site);
    console.log(site['admintotaldp']);
    console.log(site['admintotalUp']);
    console.log(site['site']);
    var connt = Vadmintotal.dataSource;
    // var dateTimestamp = date.getTime(date);
    // console.log(dateTimestamp);
    // eslint-disable-next-line max-len
    // var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "' and installdate > " + date;
    var sql = " select UserGroup.computername,UserGroup.Sitename,convert(varchar(100),UserGroup.setpsdate,23) as setpsdate,UserGroup.username from v_AutoSaveLocalUserGroup UserGroup left join v_admintotal UserGrouptotal on UserGroup.computername = UserGrouptotal.computername where  1=1 ";
    if(site['admintotaldp'] > 0){
      sql += ' and  admintotal>' + site['admintotaldp'];
    }
    if(site['admintotalUp'] > 0){
      sql += ' and  admintotal<=' + site['admintotalUp'];
    }
    sql += ' and UserGroup.Sitename in (' + site['site'] +')';
    // var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "'";
    console.log('sql:' + sql);
    connt.connector.execute(sql, function(err, response) {
        callback(null, response);
    });
};

Vadmintotal.remoteMethod('counttotal', {
  http: {
      path: '/counttotal',
      verb: 'post',
  },
  accepts: {
    arg: 'site',
    type: 'object',
    http: {
        source: 'body',
    },
    required: false,
  },
  returns: {
      arg: 'counts',
      type: 'object',
  },
});




Vadmintotal.admintoday = (site, callback) => {
  console.log(site);
  site=site.replace('[','(');
  site=site.replace(']',')');



  let sql = " SELECT computername,username,setpsdate,Sitename,count(computername) admintotal FROM AutoSaveLocalUserGroup where Sitename in ("+site+")  group BY computername,Sitename,setpsdate,username";

  console.log('sql:' + sql);
  var connt = Vadmintotal.dataSource;
  connt.connector.execute(sql, function(err, response) {
    console.log(response);
      callback(null, response);
  });
};

Vadmintotal.remoteMethod('admintoday', {
  http: {
    path: '/admintoday',
    verb: 'get',
},
accepts:[{
  arg:'site',
  type:'string',
  required:true
  }],
returns: {
  type:'string',
  root:true
},
});


Vadmintotal.IncreAdmintor = (site, callback) => {
  console.log(site);
  site=site.replace('[','(');
  site=site.replace(']',')');



  let sql = " select log.computername,log.username,log.setpsdate,log.Sitename from AutoSaveLocalUserGroup log left join "+
  " (SELECT * FROM v_admintotal b WHERE NOT EXISTS (SELECT 1 FROM v_admintotaldaybefore WHERE computername=b.computername and Sitename=b.Sitename) and Sitename in("+site+")) utt "+
  " on log.computername=utt.computername and log.Sitename= utt.Sitename where log.Sitename= utt.Sitename";

  console.log('sql:' + sql);
  var connt = Vadmintotal.dataSource;
  connt.connector.execute(sql, function(err, response) {
    console.log(response);
      callback(null, response);
  });
};

Vadmintotal.remoteMethod('IncreAdmintor', {
  http: {
    path: '/IncreAdmintor',
    verb: 'get',
},
accepts:[{
  arg:'site',
  type:'string',
  required:true
  }],
returns: {
  type:'string',
  root:true
},
});



};
