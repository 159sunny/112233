'use strict';

module.exports = function(Vautoappnamekey) {

};
