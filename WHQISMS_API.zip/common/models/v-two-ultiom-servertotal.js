'use strict';

module.exports = function(Vtwoultiomservertotal) {

};
