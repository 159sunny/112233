'use strict';

module.exports = function(Vautosavepatchinfo) {
    Vautosavepatchinfo.counttotal = (total, callback) => {
        var connt = Vautosavepatchinfo.dataSource;
        var date = new Date();
        date.setDate(date.getDate() - 360);
        // var dateTimestamp = date.getTime(date);
        // console.log(dateTimestamp);
        // eslint-disable-next-line max-len
        // var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "' and installdate > " + date;
        var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "' and convert(VARCHAR(10),installdate,120) < convert(VARCHAR(10),dateadd(dd,-360,getdate()),120)";
        // var sql = "SELECT count(distinct computername) FROM v_AutoSavePatchInfo where Sitename = '" + total + "'";
        // console.log('sql:' + sql);
        connt.connector.execute(sql, function(err, response) {
            callback(null, response);
        });
    };


    Vautosavepatchinfo.datalistpatch = (total, callback) => {
      var connt = Vautosavepatchinfo.dataSource;
      var sqldatalist = "SELECT distinct computername,convert(varchar(100),installdate,23) as installdate,sitename FROM v_AutoSavePatchInfo where Sitename = '" + total + "' and convert(VARCHAR(10),installdate,120) < convert(VARCHAR(10),dateadd(dd,-360,getdate()),120)";
      // console.log('sql:' + sqldatalist);
      connt.connector.execute(sqldatalist, function(err, response) {
          callback(null, response);
      });
  };


  Vautosavepatchinfo.datalistpatchAll = (site, callback) => {
    var connt = Vautosavepatchinfo.dataSource;
    var sqldatalist = "SELECT distinct computername,convert(varchar(100),installdate,23) as installdate,sitename FROM v_AutoSavePatchInfo where Sitename in( " + site['site'] +") and convert(VARCHAR(10),installdate,120) < convert(VARCHAR(10),dateadd(dd,-360,getdate()),120)";
    // console.log('sql:' + sqldatalist);
    connt.connector.execute(sqldatalist, function(err, response) {
        callback(null, response);
    });
};


Vautosavepatchinfo.remoteMethod('datalistpatchAll', {
  http: {
      path: '/datalistpatchAll',
      verb: 'post',
  },
  accepts: {
      arg: 'site',
      type: 'object',
      http: {
          source: 'body',
      },
      required: false,
  },
  returns: {
      arg: 'counts',
      type: 'object',
  },
});
    Vautosavepatchinfo.remoteMethod('counttotal', {
        http: {
            path: '/counttotal',
            verb: 'post',
        },
        accepts: {
            arg: 'total',
            type: 'string',
            http: {
                source: 'body',
            },
            required: false,
        },
        returns: {
            arg: 'counts',
            type: 'object',
        },
    });



    Vautosavepatchinfo.remoteMethod('datalistpatch', {
      http: {
          path: '/datalistpatch',
          verb: 'post',
      },
      accepts: {
          arg: 'total',
          type: 'string',
          http: {
              source: 'body',
          },
          required: false,
      },
      returns: {
          arg: 'counts',
          type: 'object',
      },
  });
};
