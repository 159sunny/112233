'use strict';

module.exports = function(Vultiomservertotal) {

};
