'use strict';

module.exports = function(Vautowinversion) {

};
