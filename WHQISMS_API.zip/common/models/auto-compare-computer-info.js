'use strict';

module.exports = function(Autocomparecomputerinfo) {

};
